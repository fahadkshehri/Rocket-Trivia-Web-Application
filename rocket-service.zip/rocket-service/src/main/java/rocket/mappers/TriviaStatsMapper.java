package rocket.mappers;

import java.util.List;

import org.apache.ibatis.annotations.Select;

import rocket.entity.GlobalLeaderBoardPosition;

public interface TriviaStatsMapper {

    /**
     * Gets the global site leader board.
     */
    @Select({
        "SELECT",
        "  p.UserId,",
        "  u.Alias,",
        "  SUM(CASE",
        "    WHEN NOT a.correct THEN -1",
        "    WHEN p.TimeElapsed <= 5 THEN 5",
        "    WHEN p.TimeElapsed <= 10 THEN 2",
        "    WHEN p.TimeElapsed <= 30 THEN 1",
        "    WHEN p.TimeElapsed <= 60 THEN 0.5",
        "    ELSE 0.1",
        "  END) AS Points,",
        "  COUNT(*) AS NumAnswered,",
        "  SUM(a.correct) AS NumCorrect,",
        "  COUNT(*) - SUM(a.correct) AS NumIncorrect,",
        "  COUNT(DISTINCT p.gameId) AS GamesPlayed,",
        "  AVG(p.TimeElapsed) AS AverageAnswerTime",
        "FROM User_Game_QA_Pick p",
        "JOIN User u ON (",
        "  u.userId = p.userId)",
        "JOIN Game_Question_Answer gqa ON (",
        "  gqa.gameId = p.gameId AND",
        "  gqa.gameQNum = p.gameQNum AND",
        "  gqa.gameQANum = p.gameQANum)",
        "JOIN Answer a ON (",
        "  a.questionId = gqa.questionId AND",
        "  a.answerNumber = gqa.answerNumber)",
        "GROUP BY p.UserId, u.Alias",
        "ORDER BY Points DESC",
        "LIMIT 20",
    })
    public List<GlobalLeaderBoardPosition> getGlobalLeaderBoard();
}
