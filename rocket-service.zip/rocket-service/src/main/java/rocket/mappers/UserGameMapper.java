package rocket.mappers;

import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import rocket.entity.GameQuestionAnswerReview;
import rocket.entity.UserGame;
import rocket.entity.UserGameQuestionAnswerPick;

public interface UserGameMapper {

    /**
     * Retrieves the game instance for a user id and game.
     */
    @Select({
        "SELECT ug.*",
        "FROM User_Games ug",
        "WHERE ug.userId = #{0} AND ug.gameId = #{1}"
    })
    public UserGame getUserGame(int userId, int gameId);
    
    @Insert({
        "INSERT INTO User_Games (userId, gameId, timeStarted)",
        "VALUES (#{0}, #{1}, CURRENT_TIMESTAMP)"
    })
    public void joinGame(int userId, int gameId);
    
    @Select({
        "SELECT p.*, a.correct, a.content",
        "FROM User_Game_QA_Pick p",
        "JOIN Game_Question_Answer gqa ON (",
        "  gqa.gameId = p.gameId AND",
        "  gqa.gameQNum = p.gameQNum AND",
        "  gqa.gameQANum = p.gameQANum)",
        "JOIN Answer a ON (",
        "  gqa.questionId = a.questionId AND",
        "  gqa.answerNumber = a.answerNumber)",
        "WHERE p.userId = #{0} AND p.gameId = #{1}"
    })
    public List<UserGameQuestionAnswerPick> getUserGameQuestionAnswerPicks(int userId, int gameId);

    @Select({
        "SELECT p.*, a.correct, a.content",
        "FROM User_Game_QA_Pick p",
        "JOIN Game_Question_Answer gqa ON (",
        "  gqa.gameId = p.gameId AND",
        "  gqa.gameQNum = p.gameQNum AND",
        "  gqa.gameQANum = p.gameQANum)",
        "JOIN Answer a ON (",
        "  gqa.questionId = a.questionId AND",
        "  gqa.answerNumber = a.answerNumber)",
        "WHERE p.userId = #{0} AND p.gameId = #{1} AND p.gameQNum = #{2}"
    })
    public UserGameQuestionAnswerPick getUserGameQuestionAnswerPick(int userId, int gameId, int gameQuestionNumber);
    
    @Insert({
        "INSERT INTO User_Game_QA_Pick (userId, gameId, gameQNum, gameQANum, timeChosen, timeElapsed)",
        "VALUES (#{pick.userId}, #{pick.gameId}, #{pick.gameQNum}, #{pick.gameQANum}, #{pick.timeChosen}, #{pick.timeElapsed})"
    })
    public void setUserGameQuestionAnswer(@Param("pick") UserGameQuestionAnswerPick pick);
    
    @Select({
        "SELECT",
        "  p.gameId,",
        "  gq.gameQNum AS QNum,",
        "  q.content AS Question,",
        "  a.Content AS ChosenAnswer,",
        "  aRight.Content AS CorrectAnswer,",
        "  a.Correct,",
        "  p.TimeChosen,",
        "  p.TimeElapsed",
        "FROM User_Game_QA_Pick p",
        "JOIN Game_Question gq ON (gq.gameId = p.gameId AND gq.gameQNum = p.gameQNum)",
        "JOIN Question q ON (gq.questionId = q.questionId)",
        "JOIN Game_Question_Answer gqa ON (gqa.gameId = p.gameId AND gqa.gameQNum = p.gameQNum AND gqa.GameQANum = p.GameQANum)",
        "JOIN Answer a ON (a.QuestionId = gqa.QuestionId AND a.AnswerNumber = gqa.AnswerNumber)",
        "JOIN (",
        "  Game_Question_Answer gqaRight",
        "  JOIN Answer aRight ON (",
        "    gqaRight.QuestionId = aRight.QuestionId AND",
        "    gqaRight.AnswerNumber = aRight.AnswerNumber AND",
        "    aRight.Correct = 1)",
        ") ON (gqaRight.GameId = p.gameId AND gqaRight.GameQNum = p.GameQNum)",
        "WHERE",
        "  p.userId = #{0} AND p.gameId = #{1}",
        "ORDER BY gq.gameQNum"
    })
    public List<GameQuestionAnswerReview> getGameQuestionAnswerReviews(int userId, int gameId);
}
