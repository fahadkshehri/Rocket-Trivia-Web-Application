package rocket.mappers;

import org.apache.ibatis.annotations.Select;

import java.util.*;

public interface DBInfoMapper {

    @Select("select TABLE_NAME from INFORMATION_SCHEMA.tables")
    public List<String> getTables();
    
    @Select("select CURRENT_TIMESTAMP")
    public Date getDBTime();
}
