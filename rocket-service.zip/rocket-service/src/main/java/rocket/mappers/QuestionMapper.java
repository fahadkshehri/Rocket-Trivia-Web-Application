package rocket.mappers;

import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import rocket.entity.Answer;
import rocket.entity.Category;
import rocket.entity.Question;

public interface QuestionMapper {

    @Insert({
        "INSERT INTO Question (Content, GroupId)",
        "VALUES (#{0}, #{1})"
    })
    public void createQuestion(String content, int groupId);

    @Select({"SELECT LAST_INSERT_ID()"})
    public int getLastInsertId();
    
    @Insert({
        "INSERT INTO Question_Category",
        "VALUES (#{0}, #{1})"
    })
    public void associateQuestionWithCategory(int categoryId, int questionId);
    
    @Insert({
        "INSERT INTO Answer",
        "VALUES (#{0}, #{1}, #{2}, #{3})"
    })
    public void addAnswer(int answerNumber, int questionId, String content, boolean correct);

    @Select({
        "SELECT q.*",
        "FROM Question q",
        "WHERE q.questionId = #{0}"
    })
    public Question getQuestionById(int questionId);
    
    @Select({
        "SELECT c.*",
        "FROM Question_Category qc",
        "JOIN Category c ON (qc.categoryId = c.categoryId)",
        "WHERE qc.questionId = #{0}"
    })
    public List<Category> getQuestionCategories(int questionId);

    @Select({
        "SELECT q.*",
        "FROM Question q",
        "WHERE q.groupId = #{0}"    })
    public List<Question> getQuestionsForGroup(int groupId);
    
    @Select({
        "<script>",
        "SELECT q.*",
        "FROM Question q",
        "WHERE",
        "  q.questionId IN (",
        "    SELECT DISTINCT qc.questionId",
        "    FROM Question_Category qc",
        "    WHERE",
        "      1 = 1",
        "      <if test='categoryIds != null'>",
        "        AND qc.categoryId IN",
        "          <foreach item='categoryId' index='categoryIds' collection='categoryIds' open='(' separator=',' close=')'>",
        "            #{categoryId}",
        "          </foreach>",
        "      </if>",
        "  )",
        "  <choose>",
        "    <when test='randomize'>",
        "      ORDER BY rand()",
        "    </when>",
        "    <otherwise>",
        "      ORDER BY q.questionId",
        "    </otherwise>",
        "  </choose>",
        "LIMIT #{maxResults} OFFSET #{offset}",
        "</script>"
    })
    public List<Question> searchQuestionsByCategories(
        @Param("categoryIds") List<Integer> categoryIds,
        @Param("randomize") boolean randomize,
        @Param("maxResults") int maxResults,
        @Param("offset") int offset);
    
    @Select({
        "SELECT a.*",
        "FROM Answer a",
        "WHERE a.questionId = #{0}"
    })
    public List<Answer> getQuestionAnswers(int questionId);
    
    @Select({
        "<script>",
        "SELECT a.*",
        "FROM Answer a",
        "WHERE a.questionId IN",
        "  <foreach item='questionId' index='questionIds' collection='questionIds' open='(' separator=',' close=')'>",
        "    #{questionId}",
        "  </foreach>",
        "</script>"
    })
    public List<Answer> getAllQuestionAnswers(@Param("questionIds") List<Integer> questionIds);
}
