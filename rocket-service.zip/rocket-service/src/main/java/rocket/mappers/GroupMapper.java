package rocket.mappers;

import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;

import rocket.entity.Group;
import rocket.entity.GroupWithBasicQuestionStats;
import rocket.entity.User;

public interface GroupMapper {
    
    @Insert({
        "INSERT INTO `Group` (GroupName, Description)",
        "VALUES (#{0}, #{1})"
    })
    public void createGroup(String groupName, String description);

    @Select("SELECT * FROM `Group` WHERE GroupName = #{0}")
    public Group getGroupByName(String groupName);
    
    @Select("SELECT * FROM `Group` WHERE GroupId = #{0}")
    public Group getGroupById(int groupId);
    
    @Insert({
        "INSERT INTO Group_Administrator (GroupId, UserId)",
        "VALUES (#{0}, #{1})"
    })
    public void addAdministrator(int groupId, int userId);

    @Select({
        "SELECT u.userId, u.email, u.alias",
        "FROM User u",
        "JOIN Group_Administrator ga ON (u.userId = ga.userId)",
        "WHERE",
        "  ga.groupId = #{0}"
    })
    public List<User> getAdministratorsForGroup(int groupId);
    
    @Select({
        "SELECT COUNT(*) > 0 AS isAdmin",
        "FROM Group_Administrator ga",
        "WHERE ga.UserId = #{0} and ga.GroupId = #{1}"
    })
    public boolean isAdministratorForGroup(int userId, int groupId);
    
    @Select({
        "SELECT g.*",
        "FROM `Group` g",
        "ORDER BY g.groupName",
        "LIMIT #{0} OFFSET #{1}"
    })
    public List<Group> getGroups(int maxRows, int offset);
    
    @Select({
        "SELECT g.*",
        "FROM `Group` g",
        "JOIN Group_Administrator ga ON (g.GroupId = ga.GroupId)",
        "WHERE",
        "  ga.UserId = #{0}"
    })
    public List<Group> getGroupsForUser(int userId);

    @Select({
        "SELECT g.groupId, g.groupName, COUNT(*) as QuestionCount",
        "FROM Question q",
        "JOIN `Group` g ON (q.groupId = g.groupId)",
        "GROUP BY g.groupId, g.groupName",
        "HAVING COUNT(*) > 0",
        "ORDER BY QuestionCount DESC, g.groupName"
    })
    public List<GroupWithBasicQuestionStats> getGroupWithBasicQuestionStats();
}
