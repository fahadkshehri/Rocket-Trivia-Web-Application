package rocket.mappers;

import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import rocket.entity.Category;
import rocket.entity.CategoryWithBasicQuestionStats;

public interface CategoryMapper {
    
    /**
     * Creates a new category in a group.
     */
    @Insert({
        "INSERT INTO Category (GroupId, CategoryName)",
        "VALUES (#{0}, #{1})"
    })
    public void createCategory(int groupId, String categoryName);

    @Select({
        "SELECT c.*",
        "FROM Category c",
        "WHERE c.GroupId = #{0} AND c.CategoryName = #{1}"
    })
    public Category getCategoryByGroupAndName(int groupId, String categoryName);
    
    @Select({
        "SELECT c.*",
        "FROM Category c",
        "WHERE c.CategoryId = #{0}"
    })
    public List<Category> getCategoryById(int categoryId);
    
    /**
     * Find the categories for a group.
     */
    @Select({
        "SELECT c.*",
        "FROM Category c",
        "WHERE c.GroupId = #{0}",
        "ORDER BY c.CategoryName"
    })
    public List<Category> getCategoriesForGroup(int groupId);
    
    /**
     * Returns all categories with the group name and 
     * the number of questions in the category.
     */
    @Select({
        "<script>",
        "SELECT",
        "  g.groupName, g.groupId, c.categoryName, c.categoryId, COUNT(*) AS QuestionCount",
        "FROM Question q",
        "JOIN Question_Category qc ON (q.questionId = qc.questionId)",
        "JOIN Category c ON (qc.categoryId = c.categoryId)",
        "JOIN `Group` g ON (c.groupId = g.groupId)",
        "WHERE",
        "  1 = 1",
        "  <if test='groupIds != null'>",
        "    AND g.groupId IN",
        "      <foreach item='groupId' index='groupIds' collection='groupIds' open='(' separator=',' close=')'>",
        "        #{groupId}",
        "      </foreach>",
        "  </if>",
        "GROUP BY g.groupName, g.groupId, c.categoryName, c.categoryId",
        "HAVING COUNT(*) > 0",
        "ORDER BY QuestionCount DESC, c.categoryName",
        "</script>"
    })
    public List<CategoryWithBasicQuestionStats> getCategoriesWithBasicQuestionStats(
        @Param("groupIds") List<Integer> groupIds);
    
}
