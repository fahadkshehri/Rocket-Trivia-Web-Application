package rocket.mappers;

import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import rocket.controllers.rest.request.GameSearchRequest;
import rocket.entity.Category;
import rocket.entity.Game;
import rocket.entity.GameCategoryName;
import rocket.entity.GameExtended;
import rocket.entity.GameLeaderBoardPosition;
import rocket.entity.GameQuestion;
import rocket.entity.GameQuestionAnswer;

public interface GameMapper {
    
    /**
     * Creates a new game.
     */
    @Insert({
        "INSERT INTO Game (Created, EndTime, MaxQuestionTime, UserId)",
        "VALUES (#{0}, #{1}, #{2}, #{3})"
    })
    public void createGame(Date created, Date endTime, int maxQuestionTime, int userId);

    /**
     * Retrieves the last insert id for the session.
     */
    @Select({
        "SELECT LAST_INSERT_ID()"
    })
    public int getLastInsertId();
    
    /**
     * Get a game object with it's id.
     */
    @Select({
        "SELECT g.*",
        "FROM Game g",
        "WHERE g.gameId = #{0}"
    })
    public Game getGame(int gameId);
    
    @Select({
        "<script>",
        "SELECT g.*",
        "FROM Game g",
        "WHERE",
        "  1 = 1",
        "  <if test='userId != null &amp;&amp; request.filterPlayed'>",
        "    AND NOT EXISTS (SELECT ug.gameId FROM User_Games ug WHERE ug.gameId = g.gameId AND ug.userId = #{userId})",
        "  </if>",
        "  <if test='request.filterInactive'>",
        "    AND g.endTime > CURRENT_TIMESTAMP",
        "  </if>",
        "ORDER BY CREATED DESC",
        "LIMIT #{request.maxResults} OFFSET #{request.offset}",
        "</script>"
    })
    public List<Game> getGames(@Param("request") GameSearchRequest request, @Param("userId") Integer userId);

    /**
     * Find games.
     * The game plus some extra stats are returned.
     * This is useful for showing games that a user might want to play.
     */
    @Select({
      "<script>",
      "SELECT GameExtended.*",
      "FROM (",
      "  SELECT",
      "  g.*,",
      "  (",
      "    SELECT COUNT(*)",
      "      FROM Game_Question gq",
      "      WHERE",
      "        gq.GameId = g.GameId",
      "  ) AS QuestionCount,",
      "  (",
      "    SELECT COUNT(*)",
      "    FROM User_Games ug",
      "    WHERE",
      "      ug.GameId = g.GameId",
      "  ) AS PlayerCount,",
      "  ug_stats.timeStarted,",
      "  COALESCE(ug_stats.PickCount, 0) AS PickCount,",
      "  COALESCE(ug_stats.CorrectCount, 0) AS CorrectCount,",
      "  COALESCE(ug_stats.InCorrectCount, 0) AS IncorrectCount",
      "  FROM Game g",
      "  LEFT JOIN (",
      "    SELECT",
      "      ug.gameId,",
      "      ug.timeStarted,",
      "      COUNT(*) AS PickCount,",
      "      SUM(CASE WHEN a.correct THEN 1 ELSE 0 END) AS CorrectCount,",
      "      SUM(CASE WHEN a.correct THEN 0 ELSE 1 END) AS InCorrectCount",
      "    FROM User_Games ug",
      "    JOIN User_Game_QA_Pick p ON (ug.gameId = p.gameId AND ug.userId = p.userId)",
      "    JOIN Game_Question_Answer gqa ON (gqa.gameId = p.gameId AND gqa.gameQANum = p.gameQANum AND gqa.gameQNum = p.gameQNum)",
      "    JOIN Answer a ON (a.questionId = gqa.questionId AND a.answerNumber = gqa.answerNumber)",
      "    WHERE",
      "      <choose>",
      "        <when test='userId != null'>",
      "          ug.userId = #{userId}",
      "        </when>",
      "        <otherwise>",
      "          ug.userId IS NULL",
      "        </otherwise>",
      "      </choose>",
      "    GROUP BY ug.gameId, ug.timeStarted",
      "  ) ug_stats ON (g.gameId = ug_stats.gameId)",
      ") GameExtended",
      "WHERE 1 = 1",
      "  <if test='request.filterInactive'>",
      "    AND GameExtended.EndTime &gt; CURRENT_TIMESTAMP",
      "  </if>",
      "  <if test='userId != null &amp;&amp; request.filterPlayed'>",
        "    AND GameExtended.PickCount &lt; GameExtended.QuestionCount",
        "  </if>",
        "  <if test='userId != null &amp;&amp; request.filterUnPlayed'>",
        "    AND GameExtended.PickCount &gt; 0",
        "  </if>",
      "  <choose>",
      "    <when test='request.orderByTimeStarted'>",
      "      ORDER BY GameExtended.timeStarted DESC",
      "    </when>",
      "    <otherwise>",
      "      ORDER BY GameExtended.created DESC",
      "    </otherwise>",
      "  </choose>",
        "LIMIT #{request.maxResults}",
        "OFFSET #{request.offset}",
      "</script>"
    })
    public List<GameExtended> getGameExtendeds(@Param("request") GameSearchRequest request, @Param("userId") Integer userId);
    
    /**
     * Add a question to a game.
     */
    @Insert({
        "INSERT INTO Game_Question(GameQNum, GameId, QuestionId)",
        "VALUES (#{0}, #{1}, #{2})"
    })
    public void addGameQuestion(int gameQuestionNumber, int gameId, int questionId);
    
    /**
     * Gets the game questions for a game.
     */
    @Select({
        "SELECT gq.*, q.content",
        "FROM Game_Question gq",
        "JOIN Question q ON (gq.questionId = q.questionId)",
        "WHERE gq.gameId = #{0}",
        "ORDER BY gq.GameQNum"
    })
    public List<GameQuestion> getGameQuestions(int gameId);
    
    /**
     * Returns the game questions answers for a question in a game.
     */
    @Select({
        "SELECT gqa.*, a.content, a.correct",
        "FROM Game_Question_Answer gqa",
        "JOIN Answer a ON (gqa.questionId = a.questionId AND gqa.answerNumber = a.answerNumber)",
        "WHERE gqa.gameId = #{0} AND gqa.gameQNum = #{1}",
        "ORDER BY gqa.gameQANum"
    })
    public List<GameQuestionAnswer> getGameQuestionAnswers(int gameId, int gameQNum);

    /**
     * Add a question answer to a game.
     */
    @Insert({
        "INSERT INTO Game_Question_Answer(GameQANum, GameQNum, GameId, QuestionId, AnswerNumber)",
        "VALUES (#{0}, #{1}, #{2}, #{3}, #{4})"
    })
    public void addGameQuestionAnswer(int gameQANumber, int gameQuestionNumber, int gameId, int questionId, int answerNumber); 

    /**
     * Returns the categories the game has questions for.
     */
    @Select({
        "SELECT c.*",
        "FROM Category c",
        "WHERE",
        "  c.categoryId IN (",
        "    SELECT qc.categoryId",
        "    FROM Game_Question gq",
        "    JOIN Question_Category qc ON (gq.questionId = qc.questionId)",
        "    WHERE",
        "      gq.gameId = #{0}",
        "  )"
    })
    public List<Category> getGameCategories(int gameId);
    
    /**
     * Gets the category names by gameId for multiple games.
     */
    @Select({
        "<script>",
        "SELECT DISTINCT gq.gameId, c.categoryName",
        "FROM Game_Question gq",
        "JOIN Question_Category qc ON (gq.questionId = qc.questionId)",
        "JOIN Category c ON (qc.categoryId = c.categoryId)",
        "WHERE",
        "  <choose>",
        "    <when test='gameIds.size() &gt; 0'>",
        "      gq.GameId IN",
        "      <foreach item='gameId' index='gameIds' collection='gameIds' open='(' separator=',' close=')'>",
        "        #{gameId}",
        "      </foreach>",
        "    </when>",
        "    <otherwise>",
        "      1 = 0",
        "    </otherwise>",
        "  </choose>",
        "</script>"
    })
    public List<GameCategoryName> getGameCategoriesForGameIds(@Param("gameIds") List<Integer> gameIds);    
    
    /**
     * Gets the leader board for a game showing who has answered the most questions correctly.
     */
    @Select({
        "SELECT",
        "  UG_Stats.gameId,",
        "  UG_Stats.userId,",
        "  UG_Stats.alias,",
        "  100 * UG_Stats.NumCorrect / G_Stats.QuestionCount AS PercentCorrect,",
        "  UG_Stats.NumCorrect,",
        "  UG_Stats.NumAnswered,",
        "  G_Stats.QuestionCount",
        "FROM (",
        "  SELECT",
        "    ug.gameId,",
        "    ug.userId,",
        "    u.alias,",
        "    SUM(a.correct) AS NumCorrect,",
        "    COUNT(*) AS NumAnswered",
        "  FROM User_Games ug",
        "  JOIN User u ON (",
        "    ug.userId = u.userId)",
        "  JOIN User_Game_QA_Pick p ON (",
        "    p.userId = ug.userId AND",
        "    p.gameId = ug.gameId)",
        "  JOIN Game_Question_Answer gqa ON (",
        "    gqa.gameId = p.gameId AND",
        "    gqa.gameQNum = p.gameQNum AND",
        "    gqa.gameQANum = p.gameQANum)",
        "  JOIN Answer a ON (",
        "    a.questionId = gqa.questionId AND",
        "    a.answerNumber = gqa.answerNumber)",
        "  WHERE",
        "    ug.gameId = #{gameId}",
        "  GROUP BY",
        "    ug.gameId,",
        "    ug.userId,",
        "    u.alias",
        ") UG_Stats",
        "JOIN (",
        "  SELECT",
        "    g.gameId,",
        "    COUNT(*) AS QuestionCount",
        "  FROM Game g",
        "  JOIN Game_Question gq ON (",
        "    gq.gameId = g.gameId)",
        "  WHERE",
        "    g.gameId = #{gameId}",
        "  GROUP BY g.gameId",
        ") G_Stats ON (",
        "  UG_Stats.gameId = G_Stats.gameId)",
        "ORDER BY",
        "  UG_Stats.NumCorrect DESC,",
        "  UG_Stats.NumAnswered DESC",
        "LIMIT #{topNumber}",
    })
    public List<GameLeaderBoardPosition> getGameLeaderBoard(@Param("gameId") int gameId, @Param("topNumber") int topNumber);
}
