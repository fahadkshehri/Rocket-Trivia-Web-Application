package rocket.mappers;

import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import rocket.entity.User;
import rocket.entity.UserCategoryStat;
import rocket.entity.UserDetail;

public interface UserMapper {

    @Select("SELECT * FROM User WHERE email = #{0}")
    public UserDetail getUserDetailByEmail(String email);

    @Select("SELECT userId, email, alias FROM User WHERE email = #{0}")
    public User getUserByEmail(String email);

    @Select("SELECT userId, email, alias FROM User WHERE userId = #{0}")
    public User getUserById(int userId);
    
    @Insert({
      "INSERT INTO User (Email, Alias, PasswordHash)",
      "VALUES (#{0}, #{1}, #{2})"
    })
    public void createUserDetail(
        String email, String alias, String passwordHash);
    
    /**
     * Gets statistics about a users performance for
     * question categories.
     */
    @Select({
        "SELECT CategoryStats.*",
        "FROM (",
        "  SELECT",
        "    c.CategoryName,",
        "    SUM(QStats.CorrectCount) AS CorrectCount,",
        "    SUM(QStats.IncorrectCount) AS IncorrectCount,",
        "    SUM(QStats.TimesAnswered) AS AnswerCount,",
        "    100 * SUM(QStats.CorrectCount) / SUM(QStats.TimesAnswered) AS PercentCorrect",
        "  FROM (",
        "    SELECT",
        "      a.QuestionId,",
        "      SUM(a.Correct) AS CorrectCount,",
        "      (COUNT(*) - SUM(a.Correct)) AS IncorrectCount,",
        "      COUNT(*) AS TimesAnswered",
        "    FROM User_Games ug",
        "    JOIN User_Game_QA_Pick p ON (",
        "      p.gameId = ug.gameId AND",
        "      p.userId = ug.userId)",
        "    JOIN Game_Question_Answer gqa ON (",
        "      gqa.GameId = p.GameId AND",
        "      gqa.GameQNum = p.GameQNum AND",
        "      gqa.GameQANum = p.GameQANum)",
        "    JOIN Answer a ON (",
        "      a.QuestionId = gqa.QuestionId AND",
        "      a.AnswerNumber = gqa.AnswerNumber)",
        "    WHERE",
        "      ug.userId = #{userId}",
        "    GROUP BY a.QuestionId",
        "  ) QStats",
        "  JOIN Question_Category qc ON (",
        "    qc.QuestionId = QStats.QuestionId)",
        "  JOIN Category c ON (",
        "    c.categoryId = qc.categoryId)",
        "  GROUP BY c.CategoryName",
        ") CategoryStats",
        "ORDER BY CategoryStats.PercentCorrect DESC, CategoryStats.CorrectCount DESC"
    })
    public List<UserCategoryStat> getUserCategoryStats(@Param("userId") int userId);
}
