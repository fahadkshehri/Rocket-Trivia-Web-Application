package rocket.controllers.mvc;

import java.io.*;
import java.util.*;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomeController {

    @RequestMapping("/")
    public void index(HttpServletRequest req, HttpServletResponse resp) throws Exception {
        
        // Constructs the initial HTML page to load the application.
        // html templates and javascript files are dynamically added from webapp/app/.
        //  * Those files use vue.js to construct the application.
        //  * html templates under app will be wrapped in a script tage with an id based on
        //    the file name. This allows Vue to access the templates easily.
        
        String title = "Rocket";
        
        // These are the needed JavaScript libraries used by the application.
        List<String> coreJsFiles = new ArrayList<String>(Arrays.asList(
            "/jslib/vue.js",
            "/jslib/vuex.js",
            "/jslib/vue-router.js",
            "/jslib/jquery-3.2.1.min.js",
            "/jslib/popper.min.js",
            "/jslib/bootstrap.min.js",
            "/jslib/lodash.min.js",
            "/jslib/promise-7.0.4.min.js",
            "/jslib/moment.js",
            "/jslib/numeral.min.js",
            "/jslib/rocket.js?_ts=" + System.currentTimeMillis()
        ));

        List<String> styleSheets = new ArrayList<String>(Arrays.asList(
            "/style/bootstrap.min.css"
        ));
        
        PrintWriter html = resp.getWriter();
        html.println("<!DOCTYPE HTML>");
        html.println("<html>");
        html.println("<head>");
        html.println("<title>" + title + "</title>");
        html.println("<meta http-equiv='Content-Type' content='text/html; charset=UTF-8' />");
        
        for (String styleSheet : styleSheets) {
            html.println("<link rel='stylesheet' href='" + styleSheet + "'>");
        }
        
        for (String jsFile : coreJsFiles) {
            html.println("<script src='" + jsFile + "'></script>");
        }
        
        addVueContent(req.getServletContext(), html);
        
        html.println("</head>");
        html.println("<body>");
        html.println("<div id='app'></div>");
        html.println("</body>");
        html.println("</html>");
    }

    private void addVueContent(ServletContext ctx, PrintWriter html) throws IOException {
        for (String resource : ctx.getResourcePaths("/app")) {
            if (resource.endsWith(".html")) {
                // The html files will be wrapped in a script tag with a resource name that Vue can use.
                String resourceName = resource.substring(5, resource.length() - 5);
                html.println("  <script type='text/x-template' id='" + resourceName + "-template'>");
                copyResourceContent(ctx, resource, html);
                html.println();
                html.println("  </script>");
            }
            else if (resource.endsWith(".js")) {
                // Javascript files are just included.
                html.println("  <script src='" + resource + "?_ts=" + System.currentTimeMillis() + "'></script>");
            }
            else if (resource.endsWith(".css")) {
                // CSS files are just included.
                html.println("  <link rel='stylesheet' href='" + resource + "?_ts=" + System.currentTimeMillis() + "'>");
            }
        }
    }
    
    private static void copyResourceContent(ServletContext ctx, String resource, PrintWriter out)
        throws IOException
    {
        try (Reader input = new InputStreamReader(ctx.getResourceAsStream(resource), "UTF-8")) {
            char[] buffer = new char[1024 * 4];
            int nread = 0;
            if ((nread = input.read(buffer)) >= 0) {
                out.print(new String(buffer, 0, nread));
            }
        }
    }
}
