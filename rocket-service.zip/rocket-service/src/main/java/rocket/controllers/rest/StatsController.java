package rocket.controllers.rest;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import rocket.entity.GlobalLeaderBoardPosition;
import rocket.mappers.TriviaStatsMapper;
import rocket.security.AuthTokenHandler;

@RestController
public class StatsController {
    private final static Logger logger = LoggerFactory.getLogger(StatsController.class);
    
    private SqlSessionFactory sqlSessionFactory;
    private AuthTokenHandler authTokenHandler;
    
    public StatsController(SqlSessionFactory sqlSessionFactory, AuthTokenHandler authTokenHandler) {
        this.sqlSessionFactory = sqlSessionFactory;
        this.authTokenHandler = authTokenHandler;
    }
    
    /**
     * Search for groups.
     */
    @RequestMapping(value = "/api/stats/leaderboard", method = RequestMethod.GET)
    public List<GlobalLeaderBoardPosition> getGlobalLeaderBoard() {
        try (SqlSession session = sqlSessionFactory.openSession()) {
            TriviaStatsMapper tm = session.getMapper(TriviaStatsMapper.class);
            List<GlobalLeaderBoardPosition> leaderBoard = tm.getGlobalLeaderBoard();
            GlobalLeaderBoardPosition.assignRank(leaderBoard);
            return leaderBoard;
        }
    }
}
