package rocket.controllers.rest.request;

import java.util.Date;
import java.util.List;

import rocket.validate.Validator;

public class CreateGameRequest {

    private int maxQuestions;
    private Date endTime;
    private int maxQuestionTime;
    private List<Integer> categoryIds;
    
    public int getMaxQuestions() {
        return maxQuestions;
    }
    
    public void setMaxQuestions(int maxQuestions) {
        this.maxQuestions = maxQuestions;
    }
    
    public Date getEndTime() {
        return endTime;
    }
    
    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }
    
    public int getMaxQuestionTime() {
        return maxQuestionTime;
    }
    
    public void setMaxQuestionTime(int maxQuestionTime) {
        this.maxQuestionTime = maxQuestionTime;
    }
    
    public List<Integer> getCategoryIds() {
        return categoryIds;
    }
    
    public void setCategoryIds(List<Integer> categoryIds) {
        this.categoryIds = categoryIds;
    }

    public void validate() {
        Validator.isNotNull(getCategoryIds(), "categoryIds");
        Validator.isTrue(getCategoryIds().size() > 0, "At least 1 category id must be selected.");
        Validator.isTrue(getCategoryIds().size() <= 20, "No more than 20 categories are allowed when creating a game.");
        Validator.isTrue(getMaxQuestionTime() >= 1, "The max question time must be at least 1 second.");
        Validator.isNotNull(getEndTime(), "An end time must be specified.");
    }
    
    @Override
    public String toString() {
        return "CreateGameRequest [maxQuestions=" + maxQuestions + ", endTime=" + endTime + ", maxQuestionTime="
                + maxQuestionTime + ", categoryIds=" + categoryIds + "]";
    }
}
