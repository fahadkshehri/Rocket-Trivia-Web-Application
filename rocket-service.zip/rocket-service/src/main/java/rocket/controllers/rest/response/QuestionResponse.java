package rocket.controllers.rest.response;

import java.util.List;

import rocket.entity.*;

public class QuestionResponse {

    private Question question;
    private List<Category> categories;
    private List<Answer> answers;
    
    public Question getQuestion() {
        return question;
    }
    
    public void setQuestion(Question question) {
        this.question = question;
    }
    
    public List<Category> getCategories() {
        return categories;
    }
    
    public void setCategories(List<Category> categories) {
        this.categories = categories;
    }
    
    public List<Answer> getAnswers() {
        return answers;
    }
    
    public void setAnswers(List<Answer> answers) {
        this.answers = answers;
    }
}
