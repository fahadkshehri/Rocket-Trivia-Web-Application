package rocket.controllers.rest.request;

import java.util.List;

public class QuestionSearchRequest {

    private List<Integer> categories;
    private boolean randomize = false;
    private int maxResults = 100;
    private int offset = 0;
    
    public List<Integer> getCategories() {
        return categories;
    }
    
    public void setCategories(List<Integer> categories) {
        this.categories = categories;
    }
    
    public int getMaxResults() {
        return maxResults;
    }
    
    public void setMaxResults(int maxResults) {
        this.maxResults = maxResults;
    }
    
    public boolean isRandomize() {
        return randomize;
    }

    public void setRandomize(boolean randomize) {
        this.randomize = randomize;
    }

    public int getOffset() {
        return offset;
    }

    public void setOffset(int offset) {
        this.offset = offset;
    }

    @Override
    public String toString() {
        return "QuestionSearchRequest [categories=" + categories + ", randomize=" + randomize + ", maxResults="
                + maxResults + "]";
    }
}
