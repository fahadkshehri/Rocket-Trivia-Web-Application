package rocket.controllers.rest.request;

public class UserGameQuestionAnswerPickRequest {
    private int gameQANum;
    private long timeElapsed;
    
    public int getGameQANum() {
        return gameQANum;
    }
    public void setGameQANum(int gameQANum) {
        this.gameQANum = gameQANum;
    }
    public long getTimeElapsed() {
        return timeElapsed;
    }
    public void setTimeElapsed(long timeElapsed) {
        this.timeElapsed = timeElapsed;
    }
    
    public void validate() {
        
    }
    
    @Override
    public String toString() {
        return "UserGameQuestionAnswerRequest [gameQANum=" + gameQANum + ", timeElapsed=" + timeElapsed + "]";
    }
}
