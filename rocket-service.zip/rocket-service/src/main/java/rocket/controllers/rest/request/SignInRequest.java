package rocket.controllers.rest.request;

import rocket.validate.Validator;

public class SignInRequest {
    private String email;
    private String password;
    
    public String getEmail() {
        return email;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    
    public String getPassword() {
        return password;
    }
    
    public void setPassword(String password) {
        this.password = password;
    }
    
    public void validate() {
        Validator.isNotEmpty(getPassword(), "password");
        Validator.isNotEmpty(getEmail(), "email");
    }
}
