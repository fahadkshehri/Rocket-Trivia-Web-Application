package rocket.controllers.rest.request;

import rocket.exception.ValidationException;
import rocket.validate.Validator;

/**
 * Add an administrator to a group.
 * 
 * (The groupId is part of the path parameters).
 * 
 * Either the email of the user or their id must be supplied
 * for who should be an admin.
 */
public class AddAdministratorRequest {
    
    private String administratorEmail;
    private Integer administratorId;
    
    public String getAdministratorEmail() {
        return administratorEmail;
    }
    
    public void setAdministratorEmail(String administratorEmail) {
        this.administratorEmail = administratorEmail;
    }
    
    public Integer getAdministratorId() {
        return administratorId;
    }
    
    public void setAdministratorId(Integer administratorId) {
        this.administratorId = administratorId;
    }
    
    public void validate() {
        if (!(hasAdministratorEmail() || hasAdministratorId())) {
            throw new ValidationException("Either administratorEmail or administratorId must be present.");
        }
        
        if (hasAdministratorEmail()) {
            Validator.noPrecedingOrTrailingWhitespace(administratorEmail, "administratorEmail");
        }
    }
    
    public boolean hasAdministratorId() {
        return administratorId != null && administratorId >= 0;
    }
    
    public boolean hasAdministratorEmail() {
        return administratorEmail != null && administratorEmail.length() > 0;
    }
}
