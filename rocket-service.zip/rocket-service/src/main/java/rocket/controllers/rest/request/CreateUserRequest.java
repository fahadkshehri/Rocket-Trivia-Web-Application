package rocket.controllers.rest.request;

import rocket.validate.Validator;

/**
 * Request input type for user creation.
 */
public class CreateUserRequest {

    private String alias;
    private String email;
    private String emailVerify;
    private String password;
    private String passwordVerify;
    
    public String getAlias() {
        return alias;
    }
    
    public void setAlias(String alias) {
        this.alias = alias;
    }
    
    public String getEmail() {
        return email;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    
    public String getEmailVerify() {
        return emailVerify;
    }
    
    public void setEmailVerify(String emailVerify) {
        this.emailVerify = emailVerify;
    }
    
    public String getPassword() {
        return password;
    }
    
    public void setPassword(String password) {
        this.password = password;
    }
    
    public String getPasswordVerify() {
        return passwordVerify;
    }

    public void validate() {
        Validator.noPrecedingOrTrailingWhitespace(getEmail(), "email");
        Validator.noPrecedingOrTrailingWhitespace(getPassword(), "password");
        Validator.noPrecedingOrTrailingWhitespace(getAlias(), "alias");
        Validator.valuesEqual(getEmail(), getEmailVerify(), "email", "emailVerify");
        Validator.valuesEqual(getPassword(), getPasswordVerify(), "password", "passwordVerify");
    }
    
    @Override
    public String toString() {
        // Don't print the password to the logs.
        return "UserCreationRequest [alias=" + alias + ", email=" + email + ", emailVerify=" + emailVerify + "]";
    }
}