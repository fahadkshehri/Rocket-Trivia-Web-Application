package rocket.controllers.rest.request;

public class GameSearchRequest {
    
    private int offset = 0;
    private int maxResults = 25;
    private boolean filterPlayed = true;
    private boolean filterUnPlayed = false;
    private boolean filterInactive = true;
    private boolean orderByCreated = true;
    private boolean orderByTimeStarted = false;
    
    public int getOffset() {
        return offset;
    }
    
    public void setOffset(int offset) {
        this.offset = offset;
    }
    
    public int getMaxResults() {
        return maxResults;
    }
    
    public void setMaxResults(int maxResults) {
        this.maxResults = maxResults;
    }
    
    public boolean isFilterPlayed() {
        return filterPlayed;
    }
    
    public void setFilterPlayed(boolean filterPlayed) {
        this.filterPlayed = filterPlayed;
    }
    
    public boolean isFilterUnPlayed() {
        return filterUnPlayed;
    }

    public void setFilterUnPlayed(boolean filterUnPlayed) {
        this.filterUnPlayed = filterUnPlayed;
    }

    public boolean isFilterInactive() {
        return filterInactive;
    }
    
    public void setFilterInactive(boolean filterInactive) {
        this.filterInactive = filterInactive;
    }
    
    public boolean isOrderByCreated() {
        return orderByCreated;
    }

    public void setOrderByCreated(boolean orderByCreated) {
        this.orderByCreated = orderByCreated;
    }

    public boolean isOrderByTimeStarted() {
        return orderByTimeStarted;
    }

    public void setOrderByTimeStarted(boolean orderByTimeStarted) {
        this.orderByTimeStarted = orderByTimeStarted;
    }

    public void validate() {
    }

    @Override
    public String toString() {
        return "GameSearchRequest [offset=" + offset + ", maxResults=" + maxResults + ", filterPlayed=" + filterPlayed
                + ", filterUnPlayed=" + filterUnPlayed + ", filterInactive=" + filterInactive + ", orderByCreated="
                + orderByCreated + ", orderByTimeStarted=" + orderByTimeStarted + "]";
    }
}
