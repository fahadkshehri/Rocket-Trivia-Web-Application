package rocket.controllers.rest;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import rocket.controllers.rest.request.CreateUserRequest;
import rocket.entity.Group;
import rocket.entity.User;
import rocket.entity.UserCategoryStat;
import rocket.exception.AuthenticationException;
import rocket.mappers.GroupMapper;
import rocket.mappers.UserMapper;
import rocket.security.AuthTokenHandler;
import rocket.security.AuthTokenIdentity;
import rocket.security.PasswordHash;

@RestController
public class UserController {

    private final static Logger logger = LoggerFactory.getLogger(UserController.class);
    
    private SqlSessionFactory sqlSessionFactory;
    private AuthTokenHandler authTokenHandler;
    
    public UserController(SqlSessionFactory sqlSessionFactory, AuthTokenHandler authTokenHandler) {
        this.sqlSessionFactory = sqlSessionFactory;
        this.authTokenHandler = authTokenHandler;
    }
    
    /**
     * Get user info based on the token in the request.
     */
    @RequestMapping(value = "/api/user", method = RequestMethod.GET)
    public User getUserInfoFromToken(HttpServletRequest httpRequest, HttpServletResponse httpResponse)
        throws IOException, GeneralSecurityException
    {
        AuthTokenIdentity identity = authTokenHandler.getAuthTokenIdentity(httpRequest);
        if (identity != null) {
            try (SqlSession session = sqlSessionFactory.openSession()) {
                return session.getMapper(UserMapper.class).getUserById(identity.getUserId());
            }
        }
        else {
            return null;
        }
    }

    /**
     * Get the groups that the logged in user is an administrator of.
     * @throws GeneralSecurityException 
     * @throws IOException 
     */
    @RequestMapping(value = "/api/user/groups", method = RequestMethod.GET)
    public List<Group> getGroups(HttpServletRequest httpRequest, HttpServletResponse httpResponse)
            throws IOException, GeneralSecurityException
    {
        AuthTokenIdentity identity = authTokenHandler.getAuthTokenIdentity(httpRequest);
        if (identity == null) {
            throw new AuthenticationException("Not logged in.");
        }

        try (SqlSession session = sqlSessionFactory.openSession()) {
            GroupMapper gMapper = session.getMapper(GroupMapper.class);
            return gMapper.getGroupsForUser(identity.getUserId());
        }
    }
    
    @RequestMapping(value = "/api/user/category_stats", method = RequestMethod.GET)
    public List<UserCategoryStat> getUserCategoryStatus(HttpServletRequest httpRequest, HttpServletResponse httpResponse)
            throws IOException, GeneralSecurityException
    {
        AuthTokenIdentity identity = authTokenHandler.getAuthTokenIdentity(httpRequest);
        if (identity == null) {
            throw new AuthenticationException("Not logged in.");
        }

        try (SqlSession session = sqlSessionFactory.openSession()) {
            UserMapper um = session.getMapper(UserMapper.class);
            List<UserCategoryStat> stats = um.getUserCategoryStats(identity.getUserId());
            UserCategoryStat.assignRanks(stats);
            return stats;
        }
    }
    
    /**
     * Create a new user.
     */
    @RequestMapping(value = "/api/users", method = RequestMethod.POST)
    public User create(@RequestBody CreateUserRequest request, HttpServletRequest httpRequest, HttpServletResponse httpResponse)
            throws IOException, GeneralSecurityException
    {
        logger.info("Received user creation request: " + request);
        
        request.validate();
        
        User user = null;
        try (SqlSession session = sqlSessionFactory.openSession()) {
            UserMapper userMapper = session.getMapper(UserMapper.class);
            userMapper.createUserDetail(request.getEmail(), request.getAlias(), PasswordHash.getHash(request.getPassword()));
            // Get the user after creation to get the newly generated id.
            user = userMapper.getUserByEmail(request.getEmail());
            session.commit();
        }
        logger.info("Created user: " + user);
        
        // Set the identity on the request and response.
        authTokenHandler.setIdentity(httpRequest, httpResponse, user.getUserId());
        return user;
    }
}
