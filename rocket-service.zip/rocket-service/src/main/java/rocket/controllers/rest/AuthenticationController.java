package rocket.controllers.rest;

import java.io.IOException;
import java.security.GeneralSecurityException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import rocket.entity.UserDetail;
import rocket.controllers.rest.request.SignInRequest;
import rocket.entity.User;
import rocket.exception.AuthenticationException;
import rocket.mappers.UserMapper;
import rocket.security.AuthTokenHandler;
import rocket.security.PasswordHash;

@RestController
public class AuthenticationController {

    private AuthTokenHandler authTokenHandler;
    private SqlSessionFactory sqlSessionFactory;
    
    public AuthenticationController(AuthTokenHandler authTokenHandler, SqlSessionFactory sqlSessionFactory) {
        this.authTokenHandler = authTokenHandler;
        this.sqlSessionFactory = sqlSessionFactory;
    }
    
    @RequestMapping(value = "/api/auth/signin", method = RequestMethod.POST)
    public User signin(@RequestBody SignInRequest request, HttpServletRequest httpRequest, HttpServletResponse httpResponse)
            throws IOException, GeneralSecurityException
    {
        request.validate();
        
        try (SqlSession session = sqlSessionFactory.openSession()) {
            UserMapper userMapper = session.getMapper(UserMapper.class);
            UserDetail userDetail = userMapper.getUserDetailByEmail(request.getEmail());
            
            // Verify the user and password.
            if (userDetail == null) {
                throw new AuthenticationException("There is no account for this email address.");
            }
            if (!PasswordHash.verify(request.getPassword(), userDetail.getPasswordHash())) {
                throw new AuthenticationException("Invalid password.");
            }
            
            authTokenHandler.setIdentity(httpRequest, httpResponse, userDetail.getUserId());
            return userDetail.toBasicUser();
        }
    }
    
    @RequestMapping(value = "/api/auth/signout", method = RequestMethod.POST)
    public void singout(HttpServletRequest request, HttpServletResponse response) {
        authTokenHandler.unsetIdentity(request, response);
    }
}
