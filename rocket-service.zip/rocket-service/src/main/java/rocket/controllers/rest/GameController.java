package rocket.controllers.rest;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import rocket.controllers.rest.request.CreateGameRequest;
import rocket.controllers.rest.request.GameSearchRequest;
import rocket.entity.Answer;
import rocket.entity.Category;
import rocket.entity.Game;
import rocket.entity.GameCategoryName;
import rocket.entity.GameExtended;
import rocket.entity.GameLeaderBoardPosition;
import rocket.entity.GameQuestion;
import rocket.entity.GameQuestionAnswer;
import rocket.entity.Question;
import rocket.exception.AuthenticationException;
import rocket.mappers.GameMapper;
import rocket.mappers.QuestionMapper;
import rocket.security.AuthTokenHandler;
import rocket.security.AuthTokenIdentity;


@RestController
public class GameController {

    private final static Logger logger = LoggerFactory.getLogger(GameController.class);
    
    private SqlSessionFactory sqlSessionFactory;
    private AuthTokenHandler authTokenHandler;
    
    public GameController(SqlSessionFactory sqlSessionFactory, AuthTokenHandler authTokenHandler) {
        this.sqlSessionFactory = sqlSessionFactory;
        this.authTokenHandler = authTokenHandler;
    }

    /**
     * Get the game details by gameId.
     */
    @RequestMapping(value = "/api/game/{gameId}", method = RequestMethod.GET)
    public Game getGame(@PathVariable int gameId)
    {
        try (SqlSession session = sqlSessionFactory.openSession()) {
            return session.getMapper(GameMapper.class).getGame(gameId);
        }
    }
    
    @RequestMapping(value = "/api/game/{gameId}/categories", method = RequestMethod.GET)
    public List<Category> getGameCategories(@PathVariable int gameId)
    {
        try (SqlSession session = sqlSessionFactory.openSession()) {
            return session.getMapper(GameMapper.class).getGameCategories(gameId);
        }
    }
    
    @RequestMapping(value = "/api/game/{gameId}/questions", method = RequestMethod.GET)
    public List<GameQuestion> getGameQuestions(@PathVariable int gameId)
    {
        try (SqlSession session = sqlSessionFactory.openSession()) {
            return session.getMapper(GameMapper.class).getGameQuestions(gameId);
        }
    }
  
    @RequestMapping(value = "/api/game/{gameId}/leaderboard", method = RequestMethod.GET)
    public List<GameLeaderBoardPosition> getGameLeaderboard(@PathVariable int gameId)
    {
        try (SqlSession session = sqlSessionFactory.openSession()) {
            List<GameLeaderBoardPosition> leaderBoard = session.getMapper(GameMapper.class).getGameLeaderBoard(gameId, 10);
            assignRanks(leaderBoard);
            return leaderBoard;
        }
    }
    
    @RequestMapping(value = "/api/game/{gameId}/question/{gameQNum}/answers", method = RequestMethod.GET)
    public List<GameQuestionAnswer> getGameQuestionAnswers(@PathVariable int gameId, @PathVariable int gameQNum)
    {
        try (SqlSession session = sqlSessionFactory.openSession()) {
            return session.getMapper(GameMapper.class).getGameQuestionAnswers(gameId, gameQNum);
        }
    }
    
    /**
     * Searches for and returns games with extended stat info.
     */
    @RequestMapping(value = "/api/games", method = RequestMethod.GET)
    public List<GameExtended> getGames(
        GameSearchRequest request,
        HttpServletRequest httpRequest,
        HttpServletResponse httpResponse) throws IOException, GeneralSecurityException
    {
        AuthTokenIdentity identity = authTokenHandler.getAuthTokenIdentity(httpRequest);
        Integer userId = identity != null ? identity.getUserId() : null;

        try (SqlSession session = sqlSessionFactory.openSession()) {
            GameMapper gm = session.getMapper(GameMapper.class);
                
            logger.debug("Getting games request -> {}", request);
            
            List<GameExtended> games = gm.getGameExtendeds(request, userId);

            // Look up and fill in the category names for the given games.
            List<Integer> gameIds = games.stream().map(g -> g.getGameId()).collect(Collectors.toList());
            List<GameCategoryName> gcNames = gm.getGameCategoriesForGameIds(gameIds);
            
            Map<Integer, List<String>> categoryNames = gcNames
                .stream()
                .collect(Collectors.groupingBy(
                    GameCategoryName::getGameId,
                    Collectors.mapping(GameCategoryName::getCategoryName, Collectors.toList())));
         
            for (GameExtended game : games) {
                game.setCategories(categoryNames.get(game.getGameId()));
            }
            
            return games;
        }
    }
    
    /**
     * Creates a new game.
     */
    @RequestMapping(value = "/api/games", method = RequestMethod.POST)
    public Game createGame(
        @RequestBody CreateGameRequest request,
        HttpServletRequest httpRequest,
        HttpServletResponse httpResponse) throws IOException, GeneralSecurityException
    {
        logger.info("Request: " + request);
    
        AuthTokenIdentity identity = authTokenHandler.getAuthTokenIdentity(httpRequest);
        if (identity == null) {
            throw new AuthenticationException("Not logged in.");
        }
    
        try (SqlSession session = sqlSessionFactory.openSession()) {
            QuestionMapper qm = session.getMapper(QuestionMapper.class);
            GameMapper gm = session.getMapper(GameMapper.class);
            
            // Get the questions randomized.
            List<Question> questions = qm.searchQuestionsByCategories(request.getCategoryIds(), true, request.getMaxQuestions(), 0);
            List<Integer> questionIds = questions.stream().map(q -> q.getQuestionId()).collect(Collectors.toList());

            // Get the answers in a random order.
            Map<Integer, List<Answer>> answers = qm.getAllQuestionAnswers(questionIds)
                .stream()
                .collect(Collectors.groupingBy(a -> a.getQuestionId()));
            
            // Create game
            gm.createGame(new Date(), request.getEndTime(), request.getMaxQuestionTime(), identity.getUserId());
            int gameId = gm.getLastInsertId();
            
            // Add questions and answers
            for (int qIndex = 0; qIndex < questionIds.size(); qIndex++) {
                int questionId = questionIds.get(qIndex);
                gm.addGameQuestion(qIndex, gameId, questionId);
                List<Answer> questionAnswers = getRandomAnswers(answers.get(questionId));
                for (int aIndex = 0; aIndex < questionAnswers.size(); aIndex++) {
                    gm.addGameQuestionAnswer(aIndex, qIndex, gameId, questionId, questionAnswers.get(aIndex).getAnswerNumber());
                }
            }
            
            Game game = gm.getGame(gameId);
            session.commit();
            return game;
        }
    }
    
    /**
     * From a list of answers it will produce a randomized list
     * from the original with at most 1 correct and 3 incorrect answers.
     */
    private List<Answer> getRandomAnswers(List<Answer> allAnswers) {
        List<Answer> result = new ArrayList<Answer>(4);
        List<Answer> shuffleList = new ArrayList<Answer>(allAnswers);
        Collections.shuffle(shuffleList);
        
        int trueCount = 0;
        int falseCount = 0;
        
        for (Answer a : shuffleList) {
            if (a.isCorrect()) {
                if (trueCount < 1) {
                    result.add(a);
                    trueCount++;
                }
            }
            else {
                if (falseCount < 3) {
                    result.add(a);
                    falseCount++;
                }
            }
            if (trueCount == 1 && falseCount == 3) {
                return result;
            }
        }
        
        return result;
    }
    
    /**
     * Utility for setting the rank number of the leader board position list.
     * This method assumes positions is ordered by numCorrect then numAnswered in
     * descending order.
     */
    private static void assignRanks(List<GameLeaderBoardPosition> positions) {    
        int lastCorrectCount = -1;
        int lastAnsweredCount = -1;
        int lastRank = -1;
        for (int i = 0; i < positions.size(); i++) {
            GameLeaderBoardPosition p = positions.get(i);
            if (i == 0) {
                p.setRank(1);
            }
            else if (p.getNumCorrect() == lastCorrectCount && p.getNumAnswered() == lastAnsweredCount) {
                p.setRank(lastRank);
            }
            else {
                p.setRank(i + 1);
            }
            lastCorrectCount = p.getNumCorrect();
            lastAnsweredCount = p.getNumAnswered();
            lastRank = p.getRank();
        }
    }
}
