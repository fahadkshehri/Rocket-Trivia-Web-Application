package rocket.controllers.rest;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import rocket.controllers.rest.request.CreateQuestionRequest;
import rocket.controllers.rest.request.QuestionSearchRequest;
import rocket.entity.Answer;
import rocket.entity.Category;
import rocket.entity.Question;
import rocket.exception.AuthenticationException;
import rocket.exception.AuthorizationException;
import rocket.mappers.GroupMapper;
import rocket.mappers.QuestionMapper;
import rocket.security.AuthTokenHandler;
import rocket.security.AuthTokenIdentity;

@RestController
public class QuestionController {

    private final static Logger logger = LoggerFactory.getLogger(QuestionController.class);
    
    private SqlSessionFactory sqlSessionFactory;
    private AuthTokenHandler authTokenHandler;
    
    public QuestionController(SqlSessionFactory sqlSessionFactory, AuthTokenHandler authTokenHandler) {
        this.sqlSessionFactory = sqlSessionFactory;
        this.authTokenHandler = authTokenHandler;
    }
    
    /**
     * Search for questions
     */
    @RequestMapping(value = "/api/questions", method = RequestMethod.GET)
    public List<Question> getQuestionById(QuestionSearchRequest request) {
        try (SqlSession session = sqlSessionFactory.openSession()) {
            QuestionMapper qMapper = session.getMapper(QuestionMapper.class);
            return qMapper.searchQuestionsByCategories(
                request.getCategories(),
                request.isRandomize(),
                request.getMaxResults(),
                request.getOffset());
        }
    }

    /**
     * Get questions owned by a group.
     */
    @RequestMapping(value = "/api/group/{groupId}/questions", method = RequestMethod.GET)
    public List<Question> getQuestionByGroupId(@PathVariable int groupId) {
        try (SqlSession session = sqlSessionFactory.openSession()) {
            QuestionMapper qMapper = session.getMapper(QuestionMapper.class);
            return qMapper.getQuestionsForGroup(groupId);
        }
    }
    
    /**
     * Get a question by id.
     */
    @RequestMapping(value = "/api/question/{questionId}", method = RequestMethod.GET)
    public Question getQuestionById(@PathVariable int questionId) {
        try (SqlSession session = sqlSessionFactory.openSession()) {
            QuestionMapper qMapper = session.getMapper(QuestionMapper.class);
            return qMapper.getQuestionById(questionId);
        }
    }
    
    /**
     * Get answers for a question by id.
     */
    @RequestMapping(value = "/api/question/{questionId}/answers", method = RequestMethod.GET)
    public List<Answer> getQuestionAnswersById(@PathVariable int questionId) {
        try (SqlSession session = sqlSessionFactory.openSession()) {
            QuestionMapper qMapper = session.getMapper(QuestionMapper.class);
            return qMapper.getQuestionAnswers(questionId);
        }
    }
    
    /**
     * Get the categories for a question.
     */
    @RequestMapping(value = "/api/question/{questionId}/categories", method = RequestMethod.GET)
    public List<Category> getQuestionCategories(@PathVariable int questionId) {
        try (SqlSession session = sqlSessionFactory.openSession()) {
            QuestionMapper qMapper = session.getMapper(QuestionMapper.class);
            return qMapper.getQuestionCategories(questionId);
        }
    }
    
    /**
     * Creates a new question.
     */
    @RequestMapping(value = "/api/group/{groupId}/questions", method = RequestMethod.POST)
    public Question createQuesstion(
        @PathVariable int groupId,
        @RequestBody CreateQuestionRequest request,
        HttpServletRequest httpRequest) throws IOException, GeneralSecurityException
    {    
        logger.info("Request: " + request);
    
        AuthTokenIdentity identity = authTokenHandler.getAuthTokenIdentity(httpRequest);
        if (identity == null) {
            throw new AuthenticationException("Not logged in.");
        }
    
        request.validate();
        
        try (SqlSession session = sqlSessionFactory.openSession()) {
            QuestionMapper qMapper = session.getMapper(QuestionMapper.class);
            GroupMapper gMapper = session.getMapper(GroupMapper.class);
            
            if (!gMapper.isAdministratorForGroup(identity.getUserId(), groupId)) {
                throw new AuthorizationException("You do not have permissions to this group.");
            }
            
            qMapper.createQuestion(request.getContent(), groupId);
            int questionId = qMapper.getLastInsertId();
            
            for (int i = 0; i < request.getAnswers().size(); i++) {
                CreateQuestionRequest.Answer a = request.getAnswers().get(i);
                qMapper.addAnswer(i + 1, questionId, a.getContent(), a.isCorrect());
            }
            
            for (int categoryId : request.getCategories()) {
                qMapper.associateQuestionWithCategory(categoryId, questionId);
            }
            
            Question response = qMapper.getQuestionById(questionId);
            
            session.commit();
            
            return response;
        }
    }
    
}
