package rocket.controllers.rest;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import rocket.controllers.rest.request.UserGameQuestionAnswerPickRequest;
import rocket.entity.GameQuestion;
import rocket.entity.GameQuestionAnswer;
import rocket.entity.GameQuestionAnswerReview;
import rocket.entity.UserGame;
import rocket.entity.UserGameQuestionAnswerPick;
import rocket.exception.AuthenticationException;
import rocket.exception.AuthorizationException;
import rocket.mappers.GameMapper;
import rocket.mappers.UserGameMapper;
import rocket.security.AuthTokenHandler;
import rocket.security.AuthTokenIdentity;


@RestController
public class UserGameController {

    private final static Logger logger = LoggerFactory.getLogger(UserGameController.class);
    
    private SqlSessionFactory sqlSessionFactory;
    private AuthTokenHandler authTokenHandler;
    
    public UserGameController(SqlSessionFactory sqlSessionFactory, AuthTokenHandler authTokenHandler) {
        this.sqlSessionFactory = sqlSessionFactory;
        this.authTokenHandler = authTokenHandler;
    }

    /**
     * Get the user game details by userId and gameId.
     */
    @RequestMapping(value = "/api/user_game/{userId}/{gameId}", method = RequestMethod.GET)
    public UserGame getUserGame(
        @PathVariable int userId,
        @PathVariable int gameId,
        HttpServletRequest httpRequest,
        HttpServletResponse httpResponse) throws IOException, GeneralSecurityException
    {
        logger.info("Getting user game: userId={0} gameId={1}", userId, gameId);
    
        AuthTokenIdentity identity = authTokenHandler.getAuthTokenIdentity(httpRequest);
        if (identity == null) {
            throw new AuthenticationException("Not logged in.");
        }
        if (identity.getUserId() != userId) {
            throw new AuthorizationException("You do not have access to this user game.");
        }
        
        try (SqlSession session = sqlSessionFactory.openSession()) {
            UserGame ug = session.getMapper(UserGameMapper.class).getUserGame(userId, gameId);
            logger.info("Returing: " + ug);
            return ug;
        }
    }
    
    /**
     * Join the game.
     */
    @RequestMapping(value = "/api/user_game/{userId}/{gameId}", method = RequestMethod.POST)
    public UserGame joinGame(
        @PathVariable int userId,
        @PathVariable int gameId,
        HttpServletRequest httpRequest,
        HttpServletResponse httpResponse) throws IOException, GeneralSecurityException
    {
        logger.info("Joining game userId={0} gameId={1}.", userId, gameId);
    
        AuthTokenIdentity identity = authTokenHandler.getAuthTokenIdentity(httpRequest);
        if (identity == null) {
            throw new AuthenticationException("Not logged in.");
        }
        if (identity.getUserId() != userId) {
            throw new AuthorizationException("You do not have access to this user game.");
        }
    
        try (SqlSession session = sqlSessionFactory.openSession()) {
            UserGameMapper ugm = session.getMapper(UserGameMapper.class);
            
            // If the user has already joined still consider this a success.
            UserGame userGame = ugm.getUserGame(identity.getUserId(), gameId);
            if (userGame == null)
            {
                ugm.joinGame(identity.getUserId(), gameId);
                userGame = session.getMapper(UserGameMapper.class).getUserGame(userId, gameId);
            }
            session.commit();
            logger.info("Returing: " + userGame);
            return userGame;
        }
    }
    
    @RequestMapping(value = "/api/user_game/{userId}/{gameId}/pick/{questionNumber}", method = RequestMethod.POST)
    public UserGameQuestionAnswerPick chooseUserGameQuestionAnswer(
        @PathVariable int userId,
        @PathVariable int gameId,
        @PathVariable int questionNumber,
        @RequestBody UserGameQuestionAnswerPickRequest request,
        HttpServletRequest httpRequest,
        HttpServletResponse httpResponse) throws IOException, GeneralSecurityException
    {
        logger.info("getUserGameAnswerPicks: userId={} gameId={} questionNumber={} request={}", userId, gameId, questionNumber, request);
    
        AuthTokenIdentity identity = authTokenHandler.getAuthTokenIdentity(httpRequest);
        if (identity == null) {
            throw new AuthenticationException("Not logged in.");
        }
        if (identity.getUserId() != userId) {
            throw new AuthorizationException("You do not have access to this user game.");
        }
        
        request.validate();
        
        try (SqlSession session = sqlSessionFactory.openSession()) {
            UserGameMapper ugm = session.getMapper(UserGameMapper.class);
            
            UserGameQuestionAnswerPick pick = new UserGameQuestionAnswerPick();
            pick.setUserId(userId);
            pick.setGameId(gameId);
            pick.setTimeChosen(new Date());
            pick.setTimeElapsed(request.getTimeElapsed());
            pick.setGameQNum(questionNumber);
            pick.setGameQANum(request.getGameQANum());
            
            ugm.setUserGameQuestionAnswer(pick);
            
            // Get back the details on the pick.
            pick = ugm.getUserGameQuestionAnswerPick(userId, gameId, questionNumber);
            
            session.commit();
            logger.info("Returing: " + pick);
            return pick;
        }
        
    }
    
    /**
     * Get the answer picks the user made for this game already
     */
    @RequestMapping(value = "/api/user_game/{userId}/{gameId}/picks", method = RequestMethod.GET)
    public List<UserGameQuestionAnswerPick> getUserGameAnswerPicks(
        @PathVariable int userId,
        @PathVariable int gameId,
        HttpServletRequest httpRequest,
        HttpServletResponse httpResponse) throws IOException, GeneralSecurityException
    {
        logger.info("getUserGameAnswerPicks: userId={} gameId={}", userId, gameId);
    
        AuthTokenIdentity identity = authTokenHandler.getAuthTokenIdentity(httpRequest);
        if (identity == null) {
            throw new AuthenticationException("Not logged in.");
        }
        if (identity.getUserId() != userId) {
            throw new AuthorizationException("You do not have access to this user game.");
        }
        
        try (SqlSession session = sqlSessionFactory.openSession()) {
            return session.getMapper(UserGameMapper.class).getUserGameQuestionAnswerPicks(userId, gameId);
        }
    }

    @RequestMapping(value = "/api/user_game/{userId}/{gameId}/review", method = RequestMethod.GET)
    public List<GameQuestionAnswerReview> getGameQuestionAnswerReview(
        @PathVariable int userId,
        @PathVariable int gameId,
        HttpServletRequest httpRequest,
        HttpServletResponse httpResponse) throws IOException, GeneralSecurityException
    {
        logger.info("getGameQuestionAnswerReview: userId={} gameId={}", userId, gameId);
        
        AuthTokenIdentity identity = authTokenHandler.getAuthTokenIdentity(httpRequest);
        if (identity == null) {
            throw new AuthenticationException("Not logged in.");
        }
        if (identity.getUserId() != userId) {
            throw new AuthorizationException("You do not have access to this user game.");
        }
        
        try (SqlSession session = sqlSessionFactory.openSession()) {
            return session.getMapper(UserGameMapper.class).getGameQuestionAnswerReviews(userId, gameId);
        }
    }
    
    /**
     * This is a temporary API for simulating game play.
     */
    @RequestMapping(value = "/api/user_game/{userId}/{gameId}/simulate", method = RequestMethod.POST)
    public void createGame(
        @PathVariable int userId,
        @PathVariable int gameId,
        HttpServletRequest httpRequest,
        HttpServletResponse httpResponse) throws IOException, GeneralSecurityException
    {
        logger.info("Simulating play: " + gameId);
        
        AuthTokenIdentity identity = authTokenHandler.getAuthTokenIdentity(httpRequest);
        if (identity == null) {
            throw new AuthenticationException("Not logged in.");
        }
        if (identity.getUserId() != userId) {
            throw new AuthorizationException("You do not have access to this user game.");
        }

        try (SqlSession session = sqlSessionFactory.openSession()) {
            GameMapper gm = session.getMapper(GameMapper.class);
            UserGameMapper ugm = session.getMapper(UserGameMapper.class);
            
            // Join the game if the user hasn't yet.
            UserGame userGame = ugm.getUserGame(identity.getUserId(), gameId);
            if (userGame == null) {
                logger.info("Joining game.");
                ugm.joinGame(identity.getUserId(), gameId);
            }
            
            // Get the previous answers the user made.
            List<UserGameQuestionAnswerPick> picks = ugm.getUserGameQuestionAnswerPicks(identity.getUserId(), gameId);
            Set<Integer> answeredQuestions = picks.stream().map(p -> p.getGameQNum()).collect(Collectors.toSet());
            
            Random rand = new Random();
            
            // Pick answers for the questions.
            List<GameQuestion> gameQuestions = gm.getGameQuestions(gameId);
            for (GameQuestion gq : gameQuestions) {
                if (!answeredQuestions.contains(gq.getGameQNum())) {
                    logger.info("Need to answer: " + gq);
                    
                    // Make a random choice out of the answers.
                    List<GameQuestionAnswer> possibleAnswers = gm.getGameQuestionAnswers(gameId, gq.getGameQNum());
                    GameQuestionAnswer answerChoice = possibleAnswers.get(rand.nextInt(possibleAnswers.size()));
                    logger.info("Choosing answer: " + answerChoice);
                    
                    UserGameQuestionAnswerPick pick = new UserGameQuestionAnswerPick();
                    pick.setGameId(gameId);
                    pick.setGameQANum(answerChoice.getGameQANum());
                    pick.setGameQNum(answerChoice.getGameQNum());
                    pick.setUserId(identity.getUserId());
                    pick.setTimeChosen(new Date());
                    pick.setTimeElapsed(1);
                    
                    ugm.setUserGameQuestionAnswer(pick);
                }
            }
            
            session.commit();
        }
    }
}
