package rocket.controllers.rest.request;

public class GroupSearchRequest {
    
    private int offset = 0;
    private int maxResults = 100;
    
    public int getOffset() {
        return offset;
    }
    
    public void setOffset(int offset) {
        this.offset = offset;
    }
    
    public int getMaxResults() {
        return maxResults;
    }
    
    public void setMaxResults(int maxResults) {
        this.maxResults = maxResults;
    }

    @Override
    public String toString() {
        return "GroupSearchRequest [offset=" + offset + ", maxResults=" + maxResults + "]";
    }
}
