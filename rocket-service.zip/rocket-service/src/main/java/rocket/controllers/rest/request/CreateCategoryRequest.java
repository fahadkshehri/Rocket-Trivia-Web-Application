package rocket.controllers.rest.request;

import rocket.validate.Validator;

public class CreateCategoryRequest {

    private String categoryName;

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public void validate() {
        Validator.noPrecedingOrTrailingWhitespace(getCategoryName(), "categoryName");
        Validator.isNotEmpty(getCategoryName(), "categoryName");
    }
    
    @Override
    public String toString() {
        return "CreateCategoryRequest [categoryName=" + categoryName + "]";
    }
}
