package rocket.controllers.rest.request;

import java.util.List;

public class CategoriesWithBasicQuestionStatsSearchRequest {

    private List<Integer> groupIds;

    public List<Integer> getGroupIds() {
        return groupIds;
    }

    public void setGroupIds(List<Integer> groupIds) {
        this.groupIds = groupIds;
    }

    public void validate() {
    }
    
    @Override
    public String toString() {
        return "CategoriesWithBasicQuestionStatsSearchRequest [groupIds=" + groupIds + "]";
    }
}
