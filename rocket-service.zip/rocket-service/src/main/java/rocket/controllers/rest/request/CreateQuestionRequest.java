package rocket.controllers.rest.request;

import java.util.List;

import rocket.validate.Validator;

public class CreateQuestionRequest {

    private String content;
    private List<Answer> answers;
    private List<Integer> categories;
    
    public List<Integer> getCategories() {
        return categories;
    }

    public void setCategories(List<Integer> categories) {
        this.categories = categories;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public List<Answer> getAnswers() {
        return answers;
    }

    public void setAnswers(List<Answer> answers) {
        this.answers = answers;
    }

    public void validate() {
        Validator.noPrecedingOrTrailingWhitespace(getContent(), "content");
        Validator.isNotEmpty(getContent(), "content");
        Validator.isNotNull(getAnswers(), "answers");
        Validator.isNotNull(getCategories(), "categories");
        Validator.isTrue(getCategories().size() >= 1, "At least 1 category must be associated with a question.");
        
        long correctCount = answers.stream().filter(a -> a.correct).count();
        long incorrectCount = answers.size() - correctCount;
        
        Validator.isTrue(correctCount >= 1 , "At least 1 answer must be marked as correct.");
        Validator.isTrue(incorrectCount >= 3 , "At least 3 answers must be marked as incorrect.");
        
        answers.forEach(a -> a.validate());
    }

    @Override
    public String toString() {
        return "CreateQuestionRequest [content=" + content + ", answers=" + answers + ", categories=" + categories
                + "]";
    }

    public static class Answer {
        private String content;
        private boolean correct;
        
        public String getContent() {
            return content;
        }
        
        public void setContent(String content) {
            this.content = content;
        }
        
        public boolean isCorrect() {
            return correct;
        }
        
        public void setCorrect(boolean correct) {
            this.correct = correct;
        }
        
        public void validate() {
            Validator.noPrecedingOrTrailingWhitespace(getContent(), "content");
            Validator.isNotEmpty(getContent(), "content");
        }
        
        @Override
        public String toString() {
            return "Answer [content=" + content + ", correct=" + correct + "]";
        }
    }
}
