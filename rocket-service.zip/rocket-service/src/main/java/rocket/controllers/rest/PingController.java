package rocket.controllers.rest;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import rocket.mappers.*;

@RestController
public class PingController {

    private SqlSessionFactory sqlSessionFactory;

    public PingController(SqlSessionFactory sqlSessionFactory) {
        this.sqlSessionFactory = sqlSessionFactory;
    }

    @RequestMapping("/api/ping")
    public Map<String, Object> getDBTime() {
        Map<String, Object> payload = new HashMap<String, Object>();
                
        payload.put("applicationHostTime", new Date());
        
        try (SqlSession session = sqlSessionFactory.openSession()) {
            DBInfoMapper dbInfo = session.getMapper(DBInfoMapper.class);
            payload.put("databaseHostTime", dbInfo.getDBTime());
        }
        
        return payload;
    }

    @RequestMapping("/api/tables")
    public List<String> tables() {
        try (SqlSession session = sqlSessionFactory.openSession()) {
            DBInfoMapper dbInfo = session.getMapper(DBInfoMapper.class);
            return dbInfo.getTables();
        }
    }
}
