package rocket.controllers.rest;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import rocket.controllers.rest.request.AddAdministratorRequest;
import rocket.controllers.rest.request.CreateGroupRequest;
import rocket.controllers.rest.request.GroupSearchRequest;
import rocket.entity.Group;
import rocket.entity.GroupWithBasicQuestionStats;
import rocket.entity.User;
import rocket.exception.AuthenticationException;
import rocket.exception.AuthorizationException;
import rocket.exception.ValidationException;
import rocket.mappers.GroupMapper;
import rocket.mappers.UserMapper;
import rocket.security.AuthTokenHandler;
import rocket.security.AuthTokenIdentity;

@RestController
public class GroupController {

    private final static Logger logger = LoggerFactory.getLogger(GroupController.class);
    
    private SqlSessionFactory sqlSessionFactory;
    private AuthTokenHandler authTokenHandler;
    
    public GroupController(SqlSessionFactory sqlSessionFactory, AuthTokenHandler authTokenHandler) {
        this.sqlSessionFactory = sqlSessionFactory;
        this.authTokenHandler = authTokenHandler;
    }
    
    /**
     * Search for groups.
     */
    @RequestMapping(value = "/api/groups", method = RequestMethod.GET)
    public List<Group> searchGroups(GroupSearchRequest request) {
        try (SqlSession session = sqlSessionFactory.openSession()) {
            return session.getMapper(GroupMapper.class).getGroups(request.getMaxResults(), request.getOffset());
        }
    }
    
    /**
     * Specialized API for getting groups with some basic question stats.
     * Used to help build out a game.
     */
    @RequestMapping(value = "/api/groups/basic_question_stats", method = RequestMethod.GET)
    public List<GroupWithBasicQuestionStats> getGroupsWithBasicQuestionStats()
    {
        try (SqlSession session = sqlSessionFactory.openSession()) {
            return session.getMapper(GroupMapper.class).getGroupWithBasicQuestionStats();
        }
    }
    
    /**
     * Get group details by id.
     */
    @RequestMapping(value = "/api/group/{groupId}", method = RequestMethod.GET)
    public Group getGroup(@PathVariable int groupId)
    {
        try (SqlSession session = sqlSessionFactory.openSession()) {
            return session.getMapper(GroupMapper.class).getGroupById(groupId);
        }
    }
    
    /**
     * Creates a new group with the current user setup as
     * an administrator for the group.
     */
    @RequestMapping(value = "/api/groups", method = RequestMethod.POST)
    public Group create(@RequestBody CreateGroupRequest request,
            HttpServletRequest httpRequest, HttpServletResponse httpResponse) throws IOException, GeneralSecurityException
    {
        logger.info("Request: " + request);
        
        AuthTokenIdentity identity = authTokenHandler.getAuthTokenIdentity(httpRequest);
        if (identity == null) {
            throw new AuthenticationException("Not logged in.");
        }

        request.validate();
        
        Group group = null;
        try (SqlSession session = sqlSessionFactory.openSession()) {
            GroupMapper gMapper = session.getMapper(GroupMapper.class);
            gMapper.createGroup(request.getGroupName(), request.getDescription());
            group = gMapper.getGroupByName(request.getGroupName());
            gMapper.addAdministrator(group.getGroupId(), identity.getUserId());
            session.commit();
        }
        
        logger.info("Group created: " + group);
        return group;
    }

    @RequestMapping(value = "/api/group/{groupId}/administrators", method = RequestMethod.GET)
    public List<User> getAdministrators(@PathVariable int groupId) {
        try (SqlSession session = sqlSessionFactory.openSession()) {
            return session.getMapper(GroupMapper.class).getAdministratorsForGroup(groupId);
        }
    }
    
    /**
     * Adds an administrator to a group.
     * The logged in user must also be an administrator of the group to do this.
     */
    @RequestMapping(value = "/api/group/{groupId}/administrators", method = RequestMethod.POST)
    public void addAdministrator(@PathVariable int groupId, @RequestBody AddAdministratorRequest request, HttpServletRequest httpRequest)
            throws IOException, GeneralSecurityException
    {
        logger.info("Request: " + request);
        
        AuthTokenIdentity identity = authTokenHandler.getAuthTokenIdentity(httpRequest);
        if (identity == null) {
            throw new AuthenticationException("Not logged in.");
        }

        request.validate();

        try (SqlSession session = sqlSessionFactory.openSession()) {
            GroupMapper gMapper = session.getMapper(GroupMapper.class);
            UserMapper uMapper = session.getMapper(UserMapper.class);
            
            final Group group = gMapper.getGroupById(groupId);
            if (group == null) {
                throw new ValidationException("Group " + groupId + " does not exist.");
            }
            final User newAdmin = getNewAdmin(request, uMapper);
            
            List<User> admins = gMapper.getAdministratorsForGroup(group.getGroupId());
            if (!userIdInList(identity.getUserId(), admins)) {
                throw new AuthorizationException("You do not have permissions to add an administrator to the group.");
            }
            
            if (userIdInList(newAdmin.getUserId(), admins)) {
                // The requested admin is already one - no action needed.
                return;
            }
            
            gMapper.addAdministrator(group.getGroupId(), newAdmin.getUserId());
            session.commit();
        }
    }
    
    private boolean userIdInList(int userId, List<User> users) {
        return users.stream()
            .filter(user -> user.getUserId() == userId)
            .findFirst()
            .isPresent();
    }
    
    private User getNewAdmin(AddAdministratorRequest request, UserMapper uMapper) {
        User newAdmin;
        
        // Validate existence of the user.
        if (!request.hasAdministratorId()) {
            newAdmin = uMapper.getUserByEmail(request.getAdministratorEmail());
            if (newAdmin == null) {
                throw new ValidationException("User " + request.getAdministratorEmail() + " does not exist.");
            }
        }
        else {
            newAdmin = uMapper.getUserById(request.getAdministratorId());
            if (newAdmin == null) {
                throw new ValidationException("User " + request.getAdministratorId() + " does not exist.");
            }
        }
        
        return newAdmin;
    }
}
