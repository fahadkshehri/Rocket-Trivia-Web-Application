package rocket.controllers.rest;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import rocket.exception.AuthenticationException;
import rocket.exception.AuthorizationException;
import rocket.exception.ValidationException;

@ControllerAdvice
public class RestExceptionHandler {

    @ExceptionHandler(ValidationException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    public String processValidationError(ValidationException ex) {
        return ex.getMessage();
    }
    
    /**
     * Authentication errors are surfaced as UNAUTHORIZED but
     * Authorization exceptions are mapped to FORBIDDEN.
     * This does seem wrong but is in line with how most frameworks and
     * apps handle the difference between authorization and authentication issues.
     */
    @ExceptionHandler(AuthenticationException.class)
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    @ResponseBody
    public String processAuthenticationError(AuthenticationException ex) {
        return ex.getMessage();
    }
    
    @ExceptionHandler(AuthorizationException.class)
    @ResponseStatus(HttpStatus.FORBIDDEN)
    @ResponseBody
    public String processAuthorizationError(AuthorizationException ex) {
        return ex.getMessage();
    }
}
