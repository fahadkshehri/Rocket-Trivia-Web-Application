package rocket.controllers.rest.request;

import rocket.validate.Validator;

public class CreateGroupRequest {
    private String groupName;
    private String description;

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
    
    public void validate() {
        Validator.noPrecedingOrTrailingWhitespace(getGroupName(), "groupName");
        Validator.isNotEmpty(getGroupName(), "groupName");
        Validator.noPrecedingOrTrailingWhitespace(getDescription(), "description");
        Validator.isNotEmpty(getDescription(), "description");
    }
}
