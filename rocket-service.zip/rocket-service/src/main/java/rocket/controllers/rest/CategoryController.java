package rocket.controllers.rest;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import rocket.controllers.rest.request.CategoriesWithBasicQuestionStatsSearchRequest;
import rocket.controllers.rest.request.CreateCategoryRequest;
import rocket.entity.Category;
import rocket.entity.CategoryWithBasicQuestionStats;
import rocket.exception.AuthenticationException;
import rocket.exception.AuthorizationException;
import rocket.mappers.CategoryMapper;
import rocket.mappers.GroupMapper;
import rocket.security.AuthTokenHandler;
import rocket.security.AuthTokenIdentity;

@RestController
public class CategoryController {

    private final static Logger logger = LoggerFactory.getLogger(CategoryController.class);
    
    private SqlSessionFactory sqlSessionFactory;
    private AuthTokenHandler authTokenHandler;
    
    public CategoryController(SqlSessionFactory sqlSessionFactory, AuthTokenHandler authTokenHandler) {
        this.sqlSessionFactory = sqlSessionFactory;
        this.authTokenHandler = authTokenHandler;
    }

    /**
     * Gets a view of categories including group name and some limited
     * stats on the number of questions.
     */
    @RequestMapping(value = "/api/categories/basic_question_stats", method = RequestMethod.GET)
    public List<CategoryWithBasicQuestionStats> getCategoriesWithBasicQuestionStats(
        CategoriesWithBasicQuestionStatsSearchRequest request)
    {
        request.validate();
        try (SqlSession session = sqlSessionFactory.openSession()) {
            return session.getMapper(CategoryMapper.class).getCategoriesWithBasicQuestionStats(request.getGroupIds());
        }
    }
    
    /**
     * Get the categories that are part of a group.
     */
    @RequestMapping(value = "/api/group/{groupId}/categories", method = RequestMethod.GET)
    public List<Category> getCategories(@PathVariable int groupId) {
        try (SqlSession session = sqlSessionFactory.openSession()) {
            return session.getMapper(CategoryMapper.class).getCategoriesForGroup(groupId);
        }
    }
    
    /**
     * Creates a new category.
     */
    @RequestMapping(value = "/api/group/{groupId}/categories", method = RequestMethod.POST)
    public Category createCategory(
        @PathVariable int groupId,
        @RequestBody CreateCategoryRequest request,
        HttpServletRequest httpRequest) throws IOException, GeneralSecurityException
    {    
        logger.info("Request: " + request);
    
        AuthTokenIdentity identity = authTokenHandler.getAuthTokenIdentity(httpRequest);
        if (identity == null) {
            throw new AuthenticationException("Not logged in.");
        }
    
        request.validate();
        
        try (SqlSession session = sqlSessionFactory.openSession()) {
            GroupMapper gMapper = session.getMapper(GroupMapper.class);
            CategoryMapper cMapper = session.getMapper(CategoryMapper.class);
            
            if (!gMapper.isAdministratorForGroup(identity.getUserId(), groupId)) {
                throw new AuthorizationException("You do not have permissions to this group.");
            }
            
            cMapper.createCategory(groupId, request.getCategoryName());
            Category category = cMapper.getCategoryByGroupAndName(groupId, request.getCategoryName());
            
            session.commit();
            
            return category;
        }
    }
}
