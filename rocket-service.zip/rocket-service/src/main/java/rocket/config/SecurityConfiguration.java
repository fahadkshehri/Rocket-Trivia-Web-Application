package rocket.config;

import java.io.IOException;
import java.security.GeneralSecurityException;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import rocket.security.AuthTokenHandler;

@Configuration
public class SecurityConfiguration {

    /***
     * Sets up a component for handling token authentication and generation.
     */
    @Bean
    public AuthTokenHandler authTokenHandler() throws IOException, GeneralSecurityException {
        return new AuthTokenHandler();
    }
}
