package rocket.config;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.apache.ibatis.mapping.Environment;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.apache.ibatis.transaction.TransactionFactory;
import org.apache.ibatis.transaction.jdbc.JdbcTransactionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.core.io.support.ResourcePatternResolver;
import org.springframework.core.type.classreading.CachingMetadataReaderFactory;
import org.springframework.core.type.classreading.MetadataReader;
import org.springframework.core.type.classreading.MetadataReaderFactory;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

@Configuration
public class DatabaseConfiguration {

    private final static Logger logger = LoggerFactory.getLogger(DatabaseConfiguration.class);
    
    @Value("${db.url}")
    private String dbUrl;
    
    @Value("${db.username}")
    private String dbUsername;
    
    @Value("${db.password}")
    private String dbPassword;
    
    /***
     * Setup a bean for getting a database connection to MySQL using Hikari for connection  pooling.
     */
    @Bean
    public DataSource dataSource() {
        logger.info("Creating a database pool connected to: " + dbUrl);
        HikariConfig config = new HikariConfig();
        config.setJdbcUrl(dbUrl);
        config.setUsername(dbUsername);
        config.setPassword(dbPassword);
        config.addDataSourceProperty("cachePrepStmts", "true");
        config.addDataSourceProperty("prepStmtCacheSize", "250");
        config.addDataSourceProperty("prepStmtCacheSqlLimit", "2048");

        return new HikariDataSource(config);
    }

    @Bean
    public SqlSessionFactory sqlSessionFactory() throws ClassNotFoundException, IOException {
        DataSource ds = dataSource();
        TransactionFactory txFactory = new JdbcTransactionFactory();
        Environment env = new Environment("dev", txFactory, ds);
        org.apache.ibatis.session.Configuration config = new org.apache.ibatis.session.Configuration(env);

        for(Class<?> mapper : getMappers()) {
            config.addMapper(mapper);
        }
        
        return new SqlSessionFactoryBuilder().build(config);
    }
    
    private List<Class<?>> getMappers() throws IOException, ClassNotFoundException {
        
        // adding mappers by package name wasn't working when running the built jar.
        // The code to discover classes was found in this article:
        // https://stackoverflow.com/questions/1456930/how-do-i-read-all-classes-from-a-java-package-in-the-classpath
        
        ResourcePatternResolver resourcePatternResolver = new PathMatchingResourcePatternResolver();
        MetadataReaderFactory metadataReaderFactory = new CachingMetadataReaderFactory(resourcePatternResolver);

        List<Class<?>> mappers = new ArrayList<Class<?>>();
        String packageSearchPath = ResourcePatternResolver.CLASSPATH_ALL_URL_PREFIX +
                                   "rocket/mappers/" + "*Mapper.class";
        Resource[] resources = resourcePatternResolver.getResources(packageSearchPath);
        for (Resource resource : resources) {
            if (resource.isReadable()) {
                MetadataReader metadataReader = metadataReaderFactory.getMetadataReader(resource);
                Class<?> c = Class.forName(metadataReader.getClassMetadata().getClassName());
                System.out.println("Found class: " + c);
                mappers.add(c);
            }
        }
        
        return mappers;
    }
    
}
