package rocket.security;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.GeneralSecurityException;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;

import rocket.exception.AuthenticationException;

/**
 * Handles creating auth tokens for users and verifying them.
 * This is used for logging into the application.
 */
public class AuthTokenHandler {
    
    private final static Logger logger = LoggerFactory.getLogger(AuthTokenHandler.class);
    
    private PublicKey publicKey;
    private PrivateKey privateKey;
    
    /**
     * Generates an AuthTokenHandler using specified keys.
     */
    public AuthTokenHandler(PublicKey publicKey, PrivateKey privateKey)
    {
        this.publicKey = publicKey;
        this.privateKey = privateKey;
    }
    
    /**
     * Generates an AuthTokenHandler using default private and public keys.
     */
    public AuthTokenHandler() throws IOException, GeneralSecurityException {
        this.publicKey = readResourcePublicKey("token_public_key.der");
        this.privateKey = readResourcePrivateKey("token_private_key.der");
    }
    
    /**
     * Get the identity from the HTTP request.
     * @throws GeneralSecurityException 
     * @throws IOException 
     */
    public AuthTokenIdentity getAuthTokenIdentity(HttpServletRequest request) throws IOException, GeneralSecurityException {
        AuthTokenIdentity identity = (AuthTokenIdentity) request.getAttribute(AuthConstants.IDENTITY_REQUEST_ATTRIBUTE_NAME);
        if (identity == null) {
            Cookie cookie = getAuthTokenCookie(request);
            if (cookie != null) {
                try {
                    identity = parseAndValidate(cookie.getValue());
                }
                catch (Exception e) {
                    logger.warn("Token could not be validated.", e);
                }
            }
        }
        return identity;
    }
    
    /**
     * Set the auth token identity on the HTTP response.
     */
    public void setIdentity(HttpServletRequest request, HttpServletResponse response, int userId) throws IOException, GeneralSecurityException {
        AuthTokenIdentity identity = new AuthTokenIdentity(userId);

        // Create a token and set it as a cookie.
        // Note: using a cookie in a real world app for this could make the susceptible to a CSRF attack.
        String token = generateToken(identity);
        Cookie cookie = new Cookie(AuthConstants.TOKEN_COOKIE_NAME, token);
        cookie.setMaxAge(-1);
        cookie.setPath("/");
        response.addCookie(cookie);
        
        // Also set the http request
        request.setAttribute(AuthConstants.IDENTITY_REQUEST_ATTRIBUTE_NAME, identity);
    }
    
    /**
     * Clear out the identity.
     */
    public void unsetIdentity(HttpServletRequest request, HttpServletResponse response) {
        // Remove the cookie.
        Cookie cookie = new Cookie(AuthConstants.TOKEN_COOKIE_NAME, "");
        cookie.setMaxAge(0);
        cookie.setPath("/");
        response.addCookie(cookie);
        
        // Remove from the http request.
        request.removeAttribute(AuthConstants.IDENTITY_REQUEST_ATTRIBUTE_NAME);
    }
    
    /**
     * Get the auth token identity from the given token.
     * @param token
     * @return
     * @throws IOException 
     * @throws GeneralSecurityException 
     */
    public AuthTokenIdentity parseAndValidate(String token) throws IOException, GeneralSecurityException {
        byte[] tokenBytes = Base64.getUrlDecoder().decode(token);
        
        DataInputStream din = new DataInputStream(new ByteArrayInputStream(tokenBytes));
        
        int signatureSize = din.readInt();
        if (signatureSize > tokenBytes.length || signatureSize <= 0) {
            throw new AuthenticationException("Invalid token.");
        }
        
        byte[] signature = new byte[signatureSize];
        din.readFully(signature);
        
        int payloadSize = din.readInt();
        if (payloadSize > tokenBytes.length || payloadSize <= 0) {
            throw new AuthenticationException("Invalid token.");
        }
        
        byte[] payload = new byte[payloadSize];
        din.readFully(payload);
        

        Signature signer = Signature.getInstance("SHA256withRSA");
        signer.initVerify(this.publicKey);
        
        signer.update(payload);
        if (!signer.verify(signature)) {
            throw new AuthenticationException("Token could not be verified.");
        }
        
        ObjectMapper om = new ObjectMapper();
        return om.readValue(payload, AuthTokenIdentity.class);
    }
    
    /**
     * Generate a new token.
     */
    public String generateToken(AuthTokenIdentity identity) throws IOException, GeneralSecurityException {
        ObjectMapper om = new ObjectMapper();
        
        byte[] payload = om.writeValueAsBytes(identity);
        
        Signature signer = Signature.getInstance("SHA256withRSA");
        signer.initSign(this.privateKey);
        
        signer.update(payload);
        byte[] signature = signer.sign();
        
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dout = new DataOutputStream(baos);
        
        dout.writeInt(signature.length);
        dout.write(signature);
        dout.writeInt(payload.length);
        dout.write(payload);
        dout.flush();
        
        return Base64.getUrlEncoder().encodeToString(baos.toByteArray());
    }
    
    /**
     * Get the auth token cookie if it exists.
     */
    private Cookie getAuthTokenCookie(HttpServletRequest request) {
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie cookie : request.getCookies()) {
                if (cookie.getName().equals(AuthConstants.TOKEN_COOKIE_NAME)) {
                    return cookie;
                }
            }
        }
        return null;
    }
    
    /**
     * Reads the default public key from the classpath.
     */
    private static PublicKey readResourcePublicKey(String resource) throws IOException, GeneralSecurityException {
        byte[] keyBytes = readResourceBytes(resource);
        X509EncodedKeySpec spec = new X509EncodedKeySpec(keyBytes);
        KeyFactory kf = KeyFactory.getInstance("RSA");
        return kf.generatePublic(spec);
    }
    
    /**
     * Reads the default private key from the classpath.
     */
    private static PrivateKey readResourcePrivateKey(String resource) throws IOException, GeneralSecurityException {
        byte[] keyBytes = readResourceBytes(resource);
        PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(keyBytes);
        KeyFactory kf = KeyFactory.getInstance("RSA");
        return kf.generatePrivate(spec);
    }
    
    /**
     * Reads a resource form the classpath and returns bytes.
     */
    private static byte[] readResourceBytes(String resource) throws IOException {
        try (InputStream in = AuthTokenHandler.class.getClassLoader().getResourceAsStream(resource)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buffer = new byte[1024 * 4];
            int nread;
            
            while ((nread = in.read(buffer)) > 0) {
                out.write(buffer, 0, nread);
            }
            
            out.flush();
            return out.toByteArray();
        }
    }
}
