package rocket.security;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.apache.tomcat.util.codec.binary.Base64;

public class PasswordHash {

    /**
     * Get the hash of a password.
     */
    public static String getHash(String password) throws NoSuchAlgorithmException {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] encodedHash = digest.digest(password.getBytes(StandardCharsets.UTF_8));
        return Base64.encodeBase64URLSafeString(encodedHash);
    }
    
    /**
     * Verify that the password is correct.
     */
    public static boolean verify(String password, String passwordHash) throws NoSuchAlgorithmException {
        String pHash = getHash(password);
        
        // Compare all characters to avoid remote possibility of a timing attack.
        boolean valid = true;
        for (int i = 0; i < pHash.length(); i++)
        {
            if (pHash.charAt(i) != passwordHash.charAt(i)) {
                valid = false;
            }
        }
        
        return valid;
    }
}
