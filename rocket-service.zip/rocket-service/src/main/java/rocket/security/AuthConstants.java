package rocket.security;

public class AuthConstants {
    public static final String TOKEN_COOKIE_NAME = "rocket-token";
    public static final String IDENTITY_REQUEST_ATTRIBUTE_NAME = "rocket-identity";
}
