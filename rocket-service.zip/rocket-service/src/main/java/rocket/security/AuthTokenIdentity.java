package rocket.security;

import java.util.Date;

public class AuthTokenIdentity {

    /***
     * The identity of the user.
     */
    private int userId;
    
    /**
     * When the identity was created.
     */
    private Date dateCreated;

    /**
     * Create a new AuthTokenIdentity.
     */
    public AuthTokenIdentity(int userId) {
        this.userId = userId;
        this.dateCreated = new Date();
    }
    
    /**
     * Create a new empty AuthTokenIdentity.
     */
    public AuthTokenIdentity() {
    }
    
    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    @Override
    public String toString() {
        return "AuthTokenIdentity [userId=" + userId + ", dateCreated=" + dateCreated + "]";
    }
    
}
