package rocket.entity;

public class Answer {
    private int answerNumber;
    private int questionId;
    private String content;
    private boolean correct;

    public int getAnswerNumber() {
        return answerNumber;
    }
    
    public void setAnswerNumber(int answerNumber) {
        this.answerNumber = answerNumber;
    }
    
    public int getQuestionId() {
        return questionId;
    }
    
    public void setQuestionId(int questionId) {
        this.questionId = questionId;
    }
    
    public String getContent() {
        return content;
    }
    
    public void setContent(String content) {
        this.content = content;
    }
    
    public boolean isCorrect() {
        return correct;
    }
    
    public void setCorrect(boolean correct) {
        this.correct = correct;
    }

    @Override
    public String toString() {
        return "Answer [answerNumber=" + answerNumber + ", questionId=" + questionId + ", content=" + content
                + ", correct=" + correct + "]";
    }
}
