package rocket.entity;

import java.util.List;

public class GameLeaderBoardPosition {
    private int gameId;
    private int rank;
    private int userId;
    private String alias;
    private double percentCorrect;
    private int numCorrect;
    private int numAnswered;
    private int questionCount;
    
    public int getGameId() {
        return gameId;
    }
    public void setGameId(int gameId) {
        this.gameId = gameId;
    }
    public int getRank() {
        return rank;
    }
    public void setRank(int rank) {
        this.rank = rank;
    }
    public int getUserId() {
        return userId;
    }
    public void setUserId(int userId) {
        this.userId = userId;
    }
    public String getAlias() {
        return alias;
    }
    public void setAlias(String alias) {
        this.alias = alias;
    }
    public double getPercentCorrect() {
        return percentCorrect;
    }
    public void setPercentCorrect(double percentCorrect) {
        this.percentCorrect = percentCorrect;
    }
    public int getNumCorrect() {
        return numCorrect;
    }
    public void setNumCorrect(int numCorrect) {
        this.numCorrect = numCorrect;
    }
    public int getNumAnswered() {
        return numAnswered;
    }
    public void setNumAnswered(int numAnswered) {
        this.numAnswered = numAnswered;
    }
    public int getQuestionCount() {
        return questionCount;
    }
    public void setQuestionCount(int questionCount) {
        this.questionCount = questionCount;
    }
    
    @Override
    public String toString() {
        return "GameLeaderBoardPosition [gameId=" + gameId + ", rank=" + rank + ", userId=" + userId + ", alias="
                + alias + ", percentCorrect=" + percentCorrect + ", numCorrect=" + numCorrect + ", numAnswered="
                + numAnswered + ", questionCount=" + questionCount + "]";
    }
    
}
