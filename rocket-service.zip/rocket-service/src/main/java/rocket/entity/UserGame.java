package rocket.entity;

import java.util.Date;

public class UserGame {
    private int userId;
    private int gameId;
    private Date timeStarted;
    
    public int getUserId() {
        return userId;
    }
    
    public void setUserId(int userId) {
        this.userId = userId;
    }
    
    public int getGameId() {
        return gameId;
    }
    
    public void setGameId(int gameId) {
        this.gameId = gameId;
    }
    
    public Date getTimeStarted() {
        return timeStarted;
    }
    
    public void setTimeStarted(Date timeStarted) {
        this.timeStarted = timeStarted;
    }

    @Override
    public String toString() {
        return "UserGame [userId=" + userId + ", gameId=" + gameId + ", timeStarted=" + timeStarted + "]";
    }
}
