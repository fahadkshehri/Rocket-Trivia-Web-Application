package rocket.entity;

import java.util.List;

public class GlobalLeaderBoardPosition {
    private int userId;
    private String alias;
    private double points;
    private int numAnswered;
    private int numCorrect;
    private int numIncorrect;
    private int gamesPlayed;
    private double averageAnswerTime;
    private int rank;
    public int getUserId() {
        return userId;
    }
    public void setUserId(int userId) {
        this.userId = userId;
    }
    public String getAlias() {
        return alias;
    }
    public void setAlias(String alias) {
        this.alias = alias;
    }
    public double getPoints() {
        return points;
    }
    public void setPoints(double points) {
        this.points = points;
    }
    public int getNumAnswered() {
        return numAnswered;
    }
    public void setNumAnswered(int numAnswered) {
        this.numAnswered = numAnswered;
    }
    public int getNumCorrect() {
        return numCorrect;
    }
    public void setNumCorrect(int numCorrect) {
        this.numCorrect = numCorrect;
    }
    public int getNumIncorrect() {
        return numIncorrect;
    }
    public void setNumIncorrect(int numIncorrect) {
        this.numIncorrect = numIncorrect;
    }
    public int getGamesPlayed() {
        return gamesPlayed;
    }
    public void setGamesPlayed(int gamesPlayed) {
        this.gamesPlayed = gamesPlayed;
    }
    public double getAverageAnswerTime() {
        return averageAnswerTime;
    }
    public void setAverageAnswerTime(double averageAnswerTime) {
        this.averageAnswerTime = averageAnswerTime;
    }
    public int getRank() {
        return rank;
    }
    public void setRank(int rank) {
        this.rank = rank;
    }
    
    public static void assignRank(List<GlobalLeaderBoardPosition> leaderBoard) {
        int lastRank = -1;
        double lastPoints = -1;
        for (int i = 0; i < leaderBoard.size(); i++) {
            GlobalLeaderBoardPosition p = leaderBoard.get(i);
            if (i == 0) {
                p.setRank(1);
            }
            else if (p.getPoints() == lastPoints) {
                p.setRank(lastRank);
            }
            else {
                p.setRank(i + 1);
            }
            lastRank = p.getRank();
            lastPoints = p.getPoints();
        }
    }
    
    @Override
    public String toString() {
        return "GlobalLeaderBoardPosition [userId=" + userId + ", alias=" + alias + ", points=" + points
                + ", numAnswered=" + numAnswered + ", numCorrect=" + numCorrect + ", numIncorrect=" + numIncorrect
                + ", gamesPlayed=" + gamesPlayed + ", averageAnswerTime=" + averageAnswerTime + ", rank=" + rank + "]";
    }
}
