package rocket.entity;

import java.util.Date;
import java.util.List;

public class GameExtended {
    
    private int gameId;
    private Date created;
    private Date endTime;
    private int maxQuestionTime;
    private int userId;
    private int questionCount;
    private int playerCount;
    private int pickCount;
    private int correctCount;
    private int incorrectCount;
    private Date timeStarted;
    private List<String> categories;
    
    public int getGameId() {
        return gameId;
    }
    
    public void setGameId(int gameId) {
        this.gameId = gameId;
    }
    
    public Date getCreated() {
        return created;
    }
    
    public void setCreated(Date created) {
        this.created = created;
    }
    
    public Date getEndTime() {
        return endTime;
    }
    
    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }
    
    public int getMaxQuestionTime() {
        return maxQuestionTime;
    }
    
    public void setMaxQuestionTime(int maxQuestionTime) {
        this.maxQuestionTime = maxQuestionTime;
    }
    
    public int getUserId() {
        return userId;
    }
    
    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getQuestionCount() {
        return questionCount;
    }

    public void setQuestionCount(int questionCount) {
        this.questionCount = questionCount;
    }

    public int getPickCount() {
        return pickCount;
    }

    public void setPickCount(int pickCount) {
        this.pickCount = pickCount;
    }
    
    public int getCorrectCount() {
        return correctCount;
    }

    public void setCorrectCount(int correctCount) {
        this.correctCount = correctCount;
    }

    public int getIncorrectCount() {
        return incorrectCount;
    }

    public void setIncorrectCount(int incorrectCount) {
        this.incorrectCount = incorrectCount;
    }

    public Date getTimeStarted() {
        return timeStarted;
    }

    public void setTimeStarted(Date timeStarted) {
        this.timeStarted = timeStarted;
    }

    public List<String> getCategories() {
        return categories;
    }

    public void setCategories(List<String> categories) {
        this.categories = categories;
    }
    
    public int getPlayerCount() {
        return playerCount;
    }

    public void setPlayerCount(int playerCount) {
        this.playerCount = playerCount;
    }

    @Override
    public String toString() {
        return "GameExtended [gameId=" + gameId + ", created=" + created + ", endTime=" + endTime + ", maxQuestionTime="
                + maxQuestionTime + ", userId=" + userId + ", questionCount=" + questionCount + ", playerCount="
                + playerCount + ", pickCount=" + pickCount + ", correctCount=" + correctCount + ", incorrectCount="
                + incorrectCount + ", timeStarted=" + timeStarted + ", categories=" + categories + "]";
    }
}
