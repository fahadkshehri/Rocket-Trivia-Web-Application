package rocket.entity;

import java.util.Date;

public class UserGameQuestionAnswerPick {
    private int userId;
    private int gameId;
    private int gameQNum;
    private int gameQANum;
    private Date timeChosen;
    private long timeElapsed;
    
    // Extra fields
    /** Pulled from Answer */
    private boolean correct;
    
    /** Pulled from Answer */
    private String content;
    
    public int getUserId() {
        return userId;
    }
    
    public void setUserId(int userId) {
        this.userId = userId;
    }
    
    public int getGameId() {
        return gameId;
    }
    
    public void setGameId(int gameId) {
        this.gameId = gameId;
    }
    
    public int getGameQNum() {
        return gameQNum;
    }
    
    public void setGameQNum(int gameQNum) {
        this.gameQNum = gameQNum;
    }
    
    public int getGameQANum() {
        return gameQANum;
    }
    
    public void setGameQANum(int gameQANum) {
        this.gameQANum = gameQANum;
    }
    
    public Date getTimeChosen() {
        return timeChosen;
    }
    
    public void setTimeChosen(Date timeChosen) {
        this.timeChosen = timeChosen;
    }
    
    public long getTimeElapsed() {
        return timeElapsed;
    }
    
    public void setTimeElapsed(long timeElapsed) {
        this.timeElapsed = timeElapsed;
    }
    
    public boolean isCorrect() {
        return correct;
    }

    public void setCorrect(boolean correct) {
        this.correct = correct;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    @Override
    public String toString() {
        return "UserGameQuestionAnswerPick [userId=" + userId + ", gameId=" + gameId + ", gameQNum=" + gameQNum
                + ", gameQANum=" + gameQANum + ", timeChosen=" + timeChosen + ", timeElapsed=" + timeElapsed
                + ", correct=" + correct + ", content=" + content + "]";
    }
}