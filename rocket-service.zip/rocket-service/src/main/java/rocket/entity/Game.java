package rocket.entity;

import java.util.Date;

public class Game {
    
    private int gameId;
    private Date created;
    private Date endTime;
    private int maxQuestionTime;
    private int userId;
    
    public int getGameId() {
        return gameId;
    }
    
    public void setGameId(int gameId) {
        this.gameId = gameId;
    }
    
    public Date getCreated() {
        return created;
    }
    
    public void setCreated(Date created) {
        this.created = created;
    }
    
    public Date getEndTime() {
        return endTime;
    }
    
    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }
    
    public int getMaxQuestionTime() {
        return maxQuestionTime;
    }
    
    public void setMaxQuestionTime(int maxQuestionTime) {
        this.maxQuestionTime = maxQuestionTime;
    }
    
    public int getUserId() {
        return userId;
    }
    
    public void setUserId(int userId) {
        this.userId = userId;
    }

    @Override
    public String toString() {
        return "Game [gameId=" + gameId + ", created=" + created + ", endTime=" + endTime + ", maxQuestionTime="
                + maxQuestionTime + ", userId=" + userId + "]";
    }
}
