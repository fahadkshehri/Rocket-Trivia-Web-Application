package rocket.entity;

public class GroupWithBasicQuestionStats {
    
    private int groupId;
    private String groupName;
    private int questionCount;
    
    public int getGroupId() {
        return groupId;
    }
    
    public void setGroupId(int groupId) {
        this.groupId = groupId;
    }
    
    public String getGroupName() {
        return groupName;
    }
    
    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }
    
    public int getQuestionCount() {
        return questionCount;
    }
    
    public void setQuestionCount(int questionCount) {
        this.questionCount = questionCount;
    }

    @Override
    public String toString() {
        return "GroupWithBasicQuestionStats [groupId=" + groupId + ", groupName=" + groupName + ", questionCount="
                + questionCount + "]";
    }
}
