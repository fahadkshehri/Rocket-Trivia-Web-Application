package rocket.entity;

import java.util.Date;

public class GameQuestionAnswerReview {
    private int gameId;
    private int qNum;
    private String question;
    private String chosenAnswer;
    private String correctAnswer;
    private boolean correct;
    private Date timeChosen;
    private long timeElapsed;
    
    public int getGameId() {
        return gameId;
    }
    public void setGameId(int gameId) {
        this.gameId = gameId;
    }
    public int getQNum() {
        return qNum;
    }
    public void setQNum(int qNum) {
        this.qNum = qNum;
    }
    public String getQuestion() {
        return question;
    }
    public void setQuestion(String question) {
        this.question = question;
    }
    public String getChosenAnswer() {
        return chosenAnswer;
    }
    public void setChosenAnswer(String chosenAnswer) {
        this.chosenAnswer = chosenAnswer;
    }
    public String getCorrectAnswer() {
        return correctAnswer;
    }
    public void setCorrectAnswer(String correctAnswer) {
        this.correctAnswer = correctAnswer;
    }
    public boolean isCorrect() {
        return correct;
    }
    public void setCorrect(boolean correct) {
        this.correct = correct;
    }
    public Date getTimeChosen() {
        return timeChosen;
    }
    public void setTimeChosen(Date timeChosen) {
        this.timeChosen = timeChosen;
    }
    public long getTimeElapsed() {
        return timeElapsed;
    }
    public void setTimeElapsed(long timeElapsed) {
        this.timeElapsed = timeElapsed;
    }
    
    @Override
    public String toString() {
        return "GameQuestionAnswerReview [gameId=" + gameId + ", qNum=" + qNum + ", question=" + question
                + ", chosenAnswer=" + chosenAnswer + ", correctAnswer=" + correctAnswer + ", correct=" + correct
                + ", timeChosen=" + timeChosen + ", timeElapsed=" + timeElapsed + "]";
    }
}
