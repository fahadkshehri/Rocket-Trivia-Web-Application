package rocket.entity;

import java.util.List;

public class UserCategoryStat {
    private String categoryName;
    private int correctCount;
    private int incorrectCount;
    private int answerCount;
    private double percentCorrect;
    private int rank;
    
    public String getCategoryName() {
        return categoryName;
    }
    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }
    public int getCorrectCount() {
        return correctCount;
    }
    public void setCorrectCount(int correctCount) {
        this.correctCount = correctCount;
    }
    public int getIncorrectCount() {
        return incorrectCount;
    }
    public void setIncorrectCount(int incorrectCount) {
        this.incorrectCount = incorrectCount;
    }
    public int getAnswerCount() {
        return answerCount;
    }
    public void setAnswerCount(int answerCount) {
        this.answerCount = answerCount;
    }
    public double getPercentCorrect() {
        return percentCorrect;
    }
    public void setPercentCorrect(double percentCorrect) {
        this.percentCorrect = percentCorrect;
    }
    public int getRank() {
        return rank;
    }
    public void setRank(int rank) {
        this.rank = rank;
    }
    
    /**
     * Assign the rank to the state.
     * Assume list order.
     */
    public static void assignRanks(List<UserCategoryStat> stats) {
        for (int i = 0; i < stats.size(); i++) {
            stats.get(i).setRank(i + 1);
        }
    }
    
    @Override
    public String toString() {
        return "UserCategoryStat [categoryName=" + categoryName + ", correctCount=" + correctCount + ", incorrectCount="
                + incorrectCount + ", answerCount=" + answerCount + ", percentCorrect=" + percentCorrect + "]";
    }
}
