package rocket.entity;

public class GameQuestionAnswer {
    private int gameQANum;
    private int gameQNum;
    private int gameId;
    private int questionId;
    private int answerNumber;
    private String content;
    private boolean correct;
    public int getGameQANum() {
        return gameQANum;
    }
    public void setGameQANum(int gameQANum) {
        this.gameQANum = gameQANum;
    }
    public int getGameQNum() {
        return gameQNum;
    }
    public void setGameQNum(int gameQNum) {
        this.gameQNum = gameQNum;
    }
    public int getGameId() {
        return gameId;
    }
    public void setGameId(int gameId) {
        this.gameId = gameId;
    }
    public int getQuestionId() {
        return questionId;
    }
    public void setQuestionId(int questionId) {
        this.questionId = questionId;
    }
    public int getAnswerNumber() {
        return answerNumber;
    }
    public void setAnswerNumber(int answerNumber) {
        this.answerNumber = answerNumber;
    }
    public String getContent() {
        return content;
    }
    public void setContent(String content) {
        this.content = content;
    }
    public boolean isCorrect() {
        return correct;
    }
    public void setCorrect(boolean correct) {
        this.correct = correct;
    }
    
    @Override
    public String toString() {
        return "GameQuestionAnswer [gameQANum=" + gameQANum + ", gameQNum=" + gameQNum + ", gameId=" + gameId
                + ", questionId=" + questionId + ", answerNumber=" + answerNumber + ", content=" + content
                + ", correct=" + correct + "]";
    }
}
