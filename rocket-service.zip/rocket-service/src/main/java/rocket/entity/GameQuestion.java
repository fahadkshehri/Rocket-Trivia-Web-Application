package rocket.entity;

public class GameQuestion {

    private int gameQNum;
    private int gameId;
    private int questionId;
    private String content;
    
    public int getGameQNum() {
        return gameQNum;
    }
    
    public void setGameQNum(int gameQNum) {
        this.gameQNum = gameQNum;
    }
    
    public int getGameId() {
        return gameId;
    }
    
    public void setGameId(int gameId) {
        this.gameId = gameId;
    }
    
    public int getQuestionId() {
        return questionId;
    }
    
    public void setQuestionId(int questionId) {
        this.questionId = questionId;
    }
    
    public String getContent() {
        return content;
    }
    
    public void setContent(String content) {
        this.content = content;
    }

    @Override
    public String toString() {
        return "GameQuestion [gameQNum=" + gameQNum + ", gameId=" + gameId + ", questionId=" + questionId + ", content="
                + content + "]";
    }
}
