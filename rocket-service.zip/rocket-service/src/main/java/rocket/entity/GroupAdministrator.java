package rocket.entity;

public class GroupAdministrator {

    private int userId;
    private int groupId;
    
    public int getUserId() {
        return userId;
    }
    public void setUserId(int userId) {
        this.userId = userId;
    }
    public int getGroupId() {
        return groupId;
    }
    public void setGroupId(int groupId) {
        this.groupId = groupId;
    }
    @Override
    public String toString() {
        return "GroupAdministrator [userId=" + userId + ", groupId=" + groupId + "]";
    }
}
