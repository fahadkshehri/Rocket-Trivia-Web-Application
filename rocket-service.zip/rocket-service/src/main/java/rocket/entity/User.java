package rocket.entity;

/**
 * A version of User without a password hash.
 */
public class User {

    private int userId;
    private String email;
    private String alias;
    
    public int getUserId() {
        return userId;
    }
    public void setUserId(int userId) {
        this.userId = userId;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getAlias() {
        return alias;
    }
    public void setAlias(String alias) {
        this.alias = alias;
    }
    
    @Override
    public String toString() {
        return "UserInfo [userId=" + userId + ", email=" + email + ", alias=" + alias + "]";
    }
}
