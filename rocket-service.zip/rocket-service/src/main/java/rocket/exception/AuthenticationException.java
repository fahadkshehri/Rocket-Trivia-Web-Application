package rocket.exception;

/**
 * This exception should be thrown when the user could not authenticate.
 */
public class AuthenticationException extends RuntimeException {

    private static final long serialVersionUID = 6485905170686359136L;

    public AuthenticationException() {
        super();
    }

    public AuthenticationException(String arg0, Throwable arg1) {
        super(arg0, arg1);
    }

    public AuthenticationException(String message) {
        super(message);
    }

    public AuthenticationException(Throwable cause) {
        super(cause);
    }

}
