package rocket.exception;

/**
 * This exception means that the user was not authorized
 * to perform a certain action.
 */
public class AuthorizationException extends RuntimeException {

    private static final long serialVersionUID = -7228575674484984813L;

    public AuthorizationException() {
        super();
    }

    public AuthorizationException(String arg0, Throwable arg1) {
        super(arg0, arg1);
    }

    public AuthorizationException(String message) {
        super(message);
    }

    public AuthorizationException(Throwable cause) {
        super(cause);
    }
}
