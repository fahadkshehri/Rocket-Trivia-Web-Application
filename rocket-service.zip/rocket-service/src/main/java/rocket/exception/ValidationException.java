package rocket.exception;

/**
 * Throw this when the request input is invalid.
 */
public class ValidationException extends RuntimeException {

    private static final long serialVersionUID = -3313927867810996420L;

    public ValidationException() {
        super();
    }

    public ValidationException(String arg0, Throwable arg1) {
        super(arg0, arg1);
    }

    public ValidationException(String arg0) {
        super(arg0);
    }

    public ValidationException(Throwable arg0) {
        super(arg0);
    }
}
