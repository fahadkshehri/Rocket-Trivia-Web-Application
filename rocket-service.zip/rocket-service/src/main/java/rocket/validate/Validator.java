package rocket.validate;

import java.util.regex.*;

import rocket.exception.ValidationException;

/**
 * Utilities for validating input.
 */
public class Validator {

    public static void isTrue(boolean condition, String message) {
        if (!condition) {
            throw new ValidationException(message);
        }
    }
    
    public static void isNotNull(Object o, String fieldName) {
        if (o == null) {
            throw new ValidationException(fieldName + " is required.");
        }
    }
    
    public static void isNotEmpty(String s, String fieldName) {
        if (s == null || s.length() == 0) {
            throw new ValidationException(fieldName + " is required.");
        }
    }
    
    public static void valuesEqual(Object val1, Object val2, String field1Name, String field2Name) {
        if (!val1.equals(val2)) {
            throw new ValidationException(field1Name + " does not match " + field2Name);
        }
    }
    
    public static void noPrecedingOrTrailingWhitespace(String s, String fieldName) {
        noPrecedingWhitespace(s, fieldName);
        noTrailingWhitespace(s, fieldName);
    }
    
    public static void noPrecedingWhitespace(String s, String fieldName) {
        patternMatches(s, "(?s)^\\S.*", fieldName, "must not begin with empty spaces.");
    }
    
    public static void noTrailingWhitespace(String s, String fieldName) {
        patternMatches(s, "(?s).*\\S$", fieldName, "must not end with empty spaces.");
    }
    
    public static void patternMatches(String s, String pattern, String fieldName, String message) {
        isNotNull(s, fieldName);
        if (!Pattern.matches(pattern, s)) {
            throw new ValidationException(fieldName + " " + message);
        }
    }
}
