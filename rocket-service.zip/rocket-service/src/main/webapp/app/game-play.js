(function() {
    Vue.component('game-play', {
        
        template: '#game-play-template',
        
        data: function() {
            return {
                gameId: null,
                game: null,
                categories: null,
                questions: null,
                userGameLoaded: false,
                userGame: null,
                answerPicks: null,
                lastAnswerResult: null,
                currentQuestion: null,
                answerMessage: null
            };
        },
        
        created: function() {
            // Start loading game data.
            var self = this;
            self.gameId = self.$route.params.gameId;
            console.log("game-play: created -> " + self.gameId);
            self.loadGame();
            if (self.user != null) {
                var self = this;
                self.onUserKnown();
            }
        },
        
        computed: {
            // Expose the user object from the store.
            user: function() {
                var self = this;
                return self.$store.state.user;
            },
            categoryNames: function() {
                var self = this;
                return _.map(self.categories, function(c) { return c.categoryName; });
            },
            gameState: function() {
                var self = this;
                if (self.user == null || self.game == null || self.categories == null ||
                    self.questions == null || !self.userGameLoaded || self.answerPicks == null)
                {
                    return 'loading';
                }
                else if (self.userGameLoaded && !self.userGame)
                {
                    return 'not_started';
                }
                else if (self.questions.length == self.answerPicks.length)
                {
                    return 'completed';
                }
                else if (self.currentQuestion != null)
                {
                    return 'question';
                }
                else
                {
                    return 'wait';
                }
            },
            questionsCorrect: function() {
                var self = this;
                return _.filter(self.answerPicks, function(a) { return a.correct; }).length;
            },
            questionsIncorrect: function() {
                var self = this;
                return _.filter(self.answerPicks, function(a) { return !a.correct; }).length;
            }
        },
        
        watch: {
            user: function() {
                // When the user is loaded trigger extra loading.
                var self = this;
                self.onUserKnown();
            }
        },
        
        methods: {
            
            // When the user is known, load user game details.
            onUserKnown: function() {
                var self = this;
                console.log("Have user: ", self.user.userId);
                self.loadUserGame();
            },
            
            // Load game details.
            loadGame: function() {
                var self = this;
                Promise.resolve($.ajax("/api/game/" + self.gameId)).then(
                    _.bind(self.onGame, self),
                    _.bind(self.onFailure, self));
                Promise.resolve($.ajax("/api/game/" + self.gameId + "/categories")).then(
                        _.bind(self.onCategories, self),
                        _.bind(self.onFailure, self));
                Promise.resolve($.ajax("/api/game/" + self.gameId + "/questions")).then(
                        _.bind(self.onQuestions, self),
                        _.bind(self.onFailure, self));
            },
            
            // Load user game details.
            loadUserGame: function() {
                var self = this;
                Promise.resolve($.ajax("/api/user_game/" + self.user.userId + "/" + self.gameId)).then(
                        _.bind(self.onUserGame, self),
                        _.bind(self.onFailure, self));
                Promise.resolve($.ajax("/api/user_game/" + self.user.userId + "/" + self.gameId + "/picks")).then(
                        _.bind(self.onUserGameAnswerPicks, self),
                        _.bind(self.onFailure, self));
            },
            
            // The user wants to start playing a new game.
            onPlay: function() {
                var self = this;
                console.log("Joining game.");
                
                var p = Promise.resolve($.ajax("/api/user_game/" + self.user.userId + "/" + self.gameId,  {
                    method: 'POST'
                }));
                p.then(
                    _.bind(self.loadUserGame, self),
                    _.bind(self.onFailure, self));
            },
            
            onNextQuestion: function() {
                var self = this;
                self.answerMessage = null;
                
                if (self.answerPicks.length >= self.questions.length) {
                    return;
                }
                
                var question = self.questions[self.answerPicks.length];
                console.log("Question: ", question);

                // Get the answers to display for the question.
                Promise.resolve($.ajax("/api/game/" + self.gameId + "/question/" + question.gameQNum + "/answers")).then(
                    function(answers) {
                        self.onQuestionReady(question, answers);
                    },
                    _.bind(self.onFailure, self));
                
            },
            
            onQuestionReady: function(question, answers) {
                var self = this;
                // The UI state will change based on this being set.
                console.log("Ready to show question.")
                self.currentQuestion = {
                    question: question,
                    answers: answers,
                    started: new Date()
                };
            },
            
            onAnswerChosen: function(gameQANum) {
                var self = this;
                console.log("User chose: " + gameQANum);
                
                var url = "/api/user_game/" + self.user.userId + "/" + self.gameId + "/pick/" + self.currentQuestion.question.gameQNum;
                var p = Promise.resolve($.ajax(url,  {
                    method: 'POST',
                    contentType: 'application/json; charset=utf-8',
                    data: JSON.stringify({
                        gameQANum: gameQANum,
                        timeElapsed: (new Date().getTime() - self.currentQuestion.started.getTime()) / 1000
                    })
                }));
                p.then(
                    _.bind(self.onAnswerEvaluated, self),
                    _.bind(self.onFailure, self));
            },
            
            onAnswerEvaluated: function(answerPick) {
                var self = this;
                console.log("Answer evaluated: ", answerPick);
                
                self.answerPicks.push(answerPick);
                
                if (answerPick.correct) {
                    self.answerMessage = "You are correct!";
                }
                else {
                    var rightAnswer = _.find(self.currentQuestion.answers, function(a) { return a.correct; });
                    self.answerMessage = "Sorry, the answer was: '" + rightAnswer.content + "'";
                }
                self.currentQuestion = null;
            },
            
            // Game details retrieved
            onGame: function(game) {
                var self = this;
                self.game = game;
                console.log("onGame: ", game);
            },

            // Categories retrieved
            onCategories: function(categories) {
                var self = this;
                self.categories = categories;
                console.log("onCategories: ", categories);
            },

            // Questions retrieved
            onQuestions: function(questions) {
                var self = this;
                self.questions = questions;
                console.log("questions: ", questions);
            },

            // UserGame retrieved
            onUserGame: function(userGame) {
                var self = this;
                self.userGame = userGame;
                self.userGameLoaded = true;
                console.log("userGame: ", userGame, " -> ", !!userGame);
            },

            // Answer Picks retrieved
            onUserGameAnswerPicks: function(answerPicks) {
                var self = this;
                self.answerPicks = answerPicks;
                console.log("answerPicks: ", answerPicks);
            },
            
            // Hack for simulating game play.
            onPlaySimulate: function() {
                var self = this;
                console.log("Simulating play.");
                
                var p = Promise.resolve($.ajax("/api/user_game/" + self.user.userId + "/" + self.gameId + "/simulate",  {
                    method: 'POST',
                    contentType: 'application/json; charset=utf-8',
                    data: JSON.stringify({
                        administratorEmail: self.email
                    })
                }));
                p.then(
                    _.bind(self.onPlaySimulated, self),
                    _.bind(self.onFailure, self));
            },
            
            // Play simulation done.
            onPlaySimulated: function() {
                this.$store.commit('setMessage', "Play simulated.");
            },
            
            onFailure: function(result) {
                this.$store.commit('setErrorMessage', result.responseText);
            }
        }
    });
})();