(function() {
    Vue.component('home-creator', {
        template: '#home-creator-template',
        data: function() {
            return {
                groups: []
            };
        },
        created: function() {
            var self = this;
            var p = Promise.resolve($.ajax("/api/user/groups"));
            p.then(
                _.bind(self.onGroupsRetrieved, self),
                _.bind(self.onFailure, self));
        },
        methods: {
            onGroupsRetrieved: function(groups) {
                var self = this;
                self.groups = groups;
            },
            onFailure: function(result) {
                var self = this;
                self.$store.commit('setErrorMessage', result.responseText);
            }
        }
    });
})();