(function() {
    Vue.component('question', {
        template: '#question-template',
        data: function() {
            return {
                questionId: null,
                question: null,
                answers: null,
                categories: null
            };
        },
        created: function() {
            var self = this;
            self.loadQuestion();
        },
        methods: {
            loadQuestion: function() {
                var self = this;
                self.questionId = self.$route.params.questionId;
                
                // Load base question
                Promise
                    .resolve($.ajax("/api/question/" + self.questionId))
                    .then(
                        _.bind(self.onQuestionRetrieved, self),
                        _.bind(self.onFailure, self));

                // Load answers
                Promise
                    .resolve($.ajax("/api/question/" + self.questionId + "/answers"))
                    .then(
                        _.bind(self.onAnswersRetrieved, self),
                        _.bind(self.onFailure, self));

                // Load categories
                Promise
                    .resolve($.ajax("/api/question/" + self.questionId + "/categories"))
                    .then(
                        _.bind(self.onCategoriesRetrieved, self),
                        _.bind(self.onFailure, self));
                
            },
            onQuestionRetrieved: function(question) {
                var self = this;
                self.question = question;
            },
            onAnswersRetrieved: function(answers) {
                var self = this;
                self.answers = answers;
            },
            onCategoriesRetrieved: function(categories) {
                var self = this;
                self.categories = categories;
            },
            onFailure: function(result) {
                var self = this;
                self.$store.commit('setErrorMessage', result.responseText);
            }
        }
    });
})();