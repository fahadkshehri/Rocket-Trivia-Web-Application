(function() {
    Vue.component('user-create', {
        template: '#user-create-template',
        data: function() {
            return {
                alias: "",
                email: "",
                emailVerify: "",
                password: "",
                passwordVerify: ""
            };
        },
        methods: {
            
            // Called when the form is submitted.
            onSubmit: function() {
                var self = this;
                
                var result = Promise.resolve($.ajax("/api/users",  {
                    method: 'POST',
                    contentType: 'application/json; charset=utf-8',
                    data: JSON.stringify({
                        alias: self.alias,
                        email: self.email,
                        emailVerify: self.emailVerify,
                        password: self.password,
                        passwordVerify: self.passwordVerify
                    })
                }));
                
                result.then(
                    _.bind(self.onCreateSuccess, self),
                    _.bind(self.onCreateFailure, self));
            },
            
            // Callback when a user is created.
            onCreateSuccess: function(result) {
                var self = this;
                if (result != null && result.userId != null) {
                    console.log('setUser from user create: ', result);
                    self.$store.commit('setUser', result);
                    self.$store.dispatch('onSignedIn');
                }
            },
            
            // Callback when a user creation fails.
            onCreateFailure: function(result) {
                this.$store.commit('setErrorMessage', result.responseText);
            }
        }
    });
})();