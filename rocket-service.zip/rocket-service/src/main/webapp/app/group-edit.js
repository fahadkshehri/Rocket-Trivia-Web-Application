(function() {
    Vue.component('group-edit', {
        template: '#group-edit-template',
        data: function() {
            return {
                groupId: null,
                group: null
            };
        },
        created: function() {
            var self = this;
            self.groupId = self.$route.params.groupId;
            var p = Promise.resolve($.ajax("/api/group/" + self.groupId));
            p.then(
                _.bind(self.onGroupRetrieved, self),
                _.bind(self.onFailure, self));
        },
        methods: {
            onGroupRetrieved: function(result) {
                var self = this;
                self.group = result;
            },
            onFailure: function(result) {
                var self = this;
                self.$store.commit('setErrorMessage', result.responseText);
            }
        }
    });
})();