(function() {
    Vue.component('home-player', {
        template: '#home-player-template'
    });
})();