(function() {
    Vue.component('user-signin', {
        template: '#user-signin-template',
        data: function() {
            return {
                email: "",
                password: ""
            };
        },
        methods: {
            onSubmit: function() {
                var self = this;
                self.$store.dispatch('signin', { email: self.email, password: self.password });
            }
        }
    });
})();