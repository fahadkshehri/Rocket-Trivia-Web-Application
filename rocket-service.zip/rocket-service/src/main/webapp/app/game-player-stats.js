(function() {
    Vue.component('game-player-stats', {
        
        template: '#game-player-stats-template',
        
        data: function() {
            return {
                gameId: null,
                leaderBoard: null
            };
        },
        
        created: function() {
            var self = this;
            self.gameId = self.$route.params.gameId;
            self.loadLeaderBoard();
        },

        computed: {
            user: function() {
                var self = this;
                return self.$store.state.user;
            }
        },
        
        methods: {
            loadLeaderBoard: function() {
                var self = this;
                var url = "/api/game/" + self.gameId + "/leaderboard";
                Promise.resolve($.ajax(url)).then(
                    _.bind(self.onLeaderBoard, self),
                    _.bind(self.onFailure, self));
            },
            
            onLeaderBoard: function(leaderBoard) {
                var self = this;
                self.leaderBoard = leaderBoard;
            },
        
            onFailure: function() {
                this.$store.commit('setErrorMessage', result.responseText);
            }
        }
    });
})();