(function() {
    Vue.component('group-create', {
        template: '#group-create-template',
        data: function() {
            return {
                groupName: "",
                description: ""
            };
        },
        methods: {
            onSubmit: function() {
                var self = this;
                console.log("About to call group create: " + self.groupName);
                
                var promise = Promise.resolve($.ajax("/api/groups",  {
                    method: 'POST',
                    contentType: 'application/json; charset=utf-8',
                    data: JSON.stringify({
                        groupName: self.groupName,
                        description: self.description
                    })
                }));
                promise.then(
                    _.bind(self.onCreateSuccess, self),
                    _.bind(self.onCreateFailure, self));
            },
            onCreateSuccess: function(result) {
                this.$store.commit('setMessage', "Group created: " + JSON.stringify(result));
            },
            onCreateFailure: function(result) {
                this.$store.commit('setErrorMessage', result.responseText);
            }
        }
    });
})();