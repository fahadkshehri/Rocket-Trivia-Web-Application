(function() {
    Vue.component('site-layout', {
        template: '#site-layout-template',
        data: function() {
            return {
            };
        },
        computed: {
        },
        methods: {
        }
    });
})();