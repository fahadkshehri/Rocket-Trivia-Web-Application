(function() {
    Vue.component('stats-leaderboard', {
        
        template: '#stats-leaderboard-template',
        
        data: function() {
            return {
                leaderBoard: null
            };
        },
        
        created: function() {
            var self = this;
            self.loadLeaderBoard();
        },
        
        methods: {
            
            // Load leader board.
            loadLeaderBoard: function() {
                var self = this;
                Promise.resolve($.ajax("/api/stats/leaderboard")).then(
                    _.bind(self.onLeaderBoard, self),
                    _.bind(self.onFailure, self));
            },
            
            onLeaderBoard: function(leaderBoard) {
                var self = this;
                self.leaderBoard = leaderBoard;
            },
            
            onFailure: function(result) {
                this.$store.commit('setErrorMessage', result.responseText);
            }
        }
    });
})();