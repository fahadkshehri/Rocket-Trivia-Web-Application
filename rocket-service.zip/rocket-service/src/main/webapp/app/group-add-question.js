(function() {
    Vue.component('group-add-question', {
        template: '#group-add-question-template',
        
        data: function() {
            return {
                groupId: null,
                group: null,
                questionContent: null,
                categories: null,
                checkedCategories: {},
                correctAnswer: null,
                incorrectAnswers: []
            };
        },
        
        // Look up groups on startup.
        created: function() {
            var self = this;
            self.loadGroup();
            self.loadCategories();
        },
        
        methods: {
            
            loadGroup: function() {
                var self = this;
                self.groupId = self.$route.params.groupId;
                var p = Promise.resolve($.ajax("/api/group/" + self.groupId));
                return p.then(
                    _.bind(self.onGroupRetrieved, self),
                    _.bind(self.onFailure, self));
            },
            
            loadCategories: function() {
                var self = this;
                self.groupId = self.$route.params.groupId;
                var p = Promise.resolve($.ajax("/api/group/" + self.groupId + "/categories"));
                return p.then(
                    _.bind(self.onCategoriesRetrieved, self),
                    _.bind(self.onFailure, self));
            },
            
            onSubmit: function() {
                var self = this;
                
                // Build the json payload.
                var payload = {
                    content: self.questionContent,
                    answers: _.concat(
                        [{ content: self.correctAnswer, correct: true }],
                        self.incorrectAnswers.map(function(answer) {
                            return { content: answer, correct: false };
                        })
                    ),
                    categories: _.flatMap(self.checkedCategories, function(v, k) {
                        return (v) ? [k] : [];
                    })    
                };
                
                // Send a request.
                var p = Promise.resolve($.ajax("/api/group/" + self.groupId + "/questions",  {
                    method: 'POST',
                    contentType: 'application/json; charset=utf-8',
                    data: JSON.stringify(payload)
                }));

                p.then(
                    _.bind(self.onAddQuestionSuccess, self),
                    _.bind(self.onFailure, self));
            },
            
            onGroupRetrieved: function(group) {
                var self = this;
                self.group = group;
            },
            
            onCategoriesRetrieved: function(categories) {
                var self = this;
                self.categories = categories;
            },
            
            onAddQuestionSuccess: function(result) {
                var self = this;
                console.log("Question added: ", result);
                self.$store.commit('setMessage', 'Question added.');
            },
            
            onFailure: function(result) {
                var self = this;
                self.$store.commit('setErrorMessage', result.responseText);
            }
        }
    });
})();