(function() {
    Vue.component('game-find', {
        template: '#game-find-template',
        data: function() {
            return {
                games: []
            };
        },
        created: function() {
            var self = this;
            self.retrieveGames();
        },
        methods: {
            retrieveGames: function() {
                var self = this;
                var url = "/api/games";
                var p = Promise.resolve($.ajax(url));
                p.then(
                    _.bind(self.onGamesRetrieved, self),
                    _.bind(self.onFailure, self));
            },
            onGamesRetrieved: function(games) {
                var self = this;
                self.games = games;
            },
            onFailure: function(result) {
                this.$store.commit('setErrorMessage', result.responseText);
            }
        }
    });
})();