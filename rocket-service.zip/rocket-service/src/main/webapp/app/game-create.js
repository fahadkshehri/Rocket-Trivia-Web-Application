(function() {
    Vue.component('game-create', {
        
        template: '#game-create-template',
        
        data: function() {
            
            // Set the default end time to end at the end of tomorrow.
            var endTime = moment()
              .hours(0)
              .minutes(0)
              .seconds(0)
              .milliseconds(0)
              .add(2, 'days')
              .format("YYYY-MM-DDTHH:mm");

            return {
                "maxQuestions": 10,
                "maxQuestionTime": 30,
                "endTime": endTime,
                "groups": [],
                "categories": [],
                "checkedGroups": {},
                "checkedCategories": {},
                "createdGame": null
            };
        },
        
        created: function() {
            var self = this;
            self.retrieveGroups();
        },
        
        methods: {
            
            onGroupCheckboxChange: function() {
                var self = this;
                console.log("group checkbox change!");
                self.retrieveCategories(self.getCheckedGroupIds());
            },
            
            getCheckedGroupIds: function() {
                var self = this;
                return _.flatMap(self.checkedGroups, function(v, k) {
                    return (v) ? [k] : [];
                });
            },
            
            getCheckedCategoryIds: function() {
                var self = this;
                return _.flatMap(self.checkedCategories, function(v, k) {
                    return (v) ? [k] : [];
                });
            },

            retrieveCategories: function(groupIds) {
                var self = this;
                if (groupIds == null || groupIds.length == 0) {
                    self.checkedCategories = {};
                    self.categories = [];
                }
                else {
                    var url = "/api/categories/basic_question_stats?groupIds=" + encodeURIComponent(groupIds.join(","));
                    var p = Promise.resolve($.ajax(url));
                    p.then(
                        _.bind(self.onCategoriesRetrieved, self),
                        _.bind(self.onFailure, self));
                }
            },
            
            retrieveGroups: function() {
                var self = this;
                var p = Promise.resolve($.ajax("/api/groups/basic_question_stats"));
                p.then(
                    _.bind(self.onGroupsRetrieved, self),
                    _.bind(self.onFailure, self));
            },
            
            onGroupsRetrieved: function(groups) {
                var self = this;
                self.groups = groups;
                self.checkedGroups = {};
            },
            
            onCategoriesRetrieved: function(categories) {
                var self = this;
                console.log("Have categories: ", categories);
                self.categories = categories;
                self.checkedCategories = {};
            },
            
            onSubmit: function() {
                var self = this;
                
                var endTime = new Date(moment(self.endTime, "YYYY-MM-DDTHH:mm").valueOf()).toISOString();
                
                var payload = {
                    maxQuestions: self.maxQuestions,
                    endTime: endTime,
                    maxQuestionTime: self.maxQuestionTime,
                    categoryIds: self.getCheckedCategoryIds()
                };
                
                // Send a request.
                var p = Promise.resolve($.ajax("/api/games",  {
                    method: 'POST',
                    contentType: 'application/json; charset=utf-8',
                    data: JSON.stringify(payload)
                }));

                p.then(
                    _.bind(self.onCreateSuccess, self),
                    _.bind(self.onFailure, self));
                
                console.log(JSON.stringify(payload));
            },
            
            onCreateSuccess: function(game) {
                var self = this;
                self.$store.commit('setMessage', "Game created.");
                self.$router.push('/game/' + game.gameId + '/play');
            },
            
            onFailure: function(result) {
                var self = this;
                self.$store.commit('setErrorMessage', result.responseText);
            }
        }
    });
})();