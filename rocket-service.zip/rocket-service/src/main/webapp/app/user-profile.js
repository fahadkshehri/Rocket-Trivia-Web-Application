(function() {
    Vue.component('user-profile', {
        
        template: '#user-profile-template',
        
        data: function() {
            return {
                games: null,
                categoryStats: null
            };
        },
        
        created: function() {
            var self = this;
            if (self.user != null) {
                self.loadPlayedGames();
            }
            self.loadUserCategoryStats();
        },
        
        computed: {
            user: function() {
                return this.$store.state.user;
            }
        },
        
        watch: {
            user: function() {
                var self = this;
                if (self.user != null) {
                    self.loadPlayedGames();
                }
            }
        },
        
        methods: {
            
            gamePercent: function(game) {
                var self = this;
                return Math.floor(100 * (game.correctCount / game.pickCount));
            },
            
            loadUserCategoryStats: function() {
                var self = this;
                var url = "/api/user/category_stats";
                var p = Promise.resolve($.ajax(url));
                p.then(
                    _.bind(self.onCategoryStats, self),
                    _.bind(self.onFailure, self));
            },
            
            loadPlayedGames: function() {
                var self = this;
                var url = "/api/games?filterUnPlayed=true&filterPlayed=false&filterInactive=false";
                var p = Promise.resolve($.ajax(url));
                p.then(
                    _.bind(self.onGamesRetrieved, self),
                    _.bind(self.onFailure, self));
            },
            
            onCategoryStats: function(categoryStats) {
                var self = this;
                self.categoryStats = categoryStats;
            },
            
            onGamesRetrieved: function(games) {
                var self = this;
                self.games = games;
            },
            
            onFailure: function(result) {
                var self = this;
                self.$store.commit('setErrorMessage', result.responseText);
            }
        }
    });
})();