(function() {
    Vue.component('message', {
        template: '#message-template',
        data: function() {
            return {
            };
        },
        methods: {
        },
        created: function() {
            this.$store.commit('clearMessages');
        },
        computed: {
            message: function() { return this.$store.state.message; },
            errorMessage: function() { return this.$store.state.errorMessage; }
        }
    });
})();