(function() {
    Vue.component('minor-actions', {
        template: '#minor-actions-template',
        computed: {
            user: function() {
                var self = this;
                return self.$store.state.user;
            }
        }
    });
})();