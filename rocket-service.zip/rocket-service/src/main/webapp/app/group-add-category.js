(function() {
    Vue.component('group-add-category', {
        template: '#group-add-category-template',
        
        data: function() {
            return {
                groupId: null,
                group: null,
                categoryName: null
            };
        },
        
        // Look up groups on startup.
        created: function() {
            var self = this;
            self.groupId = self.$route.params.groupId;
            var p = Promise.resolve($.ajax("/api/group/" + self.groupId));
            p.then(
                _.bind(self.onGroupRetrieved, self),
                _.bind(self.onFailure, self));
        },
        
        methods: {
            onSubmit: function() {
                var self = this;

                var p = Promise.resolve($.ajax("/api/group/" + self.groupId + "/categories",  {
                    method: 'POST',
                    contentType: 'application/json; charset=utf-8',
                    data: JSON.stringify({
                        categoryName: self.categoryName
                    })
                }));
                p.then(
                    _.bind(self.onAddCategorySuccess, self),
                    _.bind(self.onFailure, self));
            },
            
            onGroupRetrieved: function(result) {
                var self = this;
                self.group = result;
            },
            
            onAddCategorySuccess: function(result) {
                var self = this;
                console.log("Category created: ", result);
                self.$store.commit('setMessage', "Category created.");
            },
            
            onFailure: function(result) {
                var self = this;
                self.$store.commit('setErrorMessage', result.responseText);
            }
        }
    });
})();