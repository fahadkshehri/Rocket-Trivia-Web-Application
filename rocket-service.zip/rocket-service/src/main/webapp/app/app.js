(function() {
    
    /**
     * Setup up for application routes.
     */
    var routes = [
        { path: '/',                            component: { template: "<home></home>" } },
        { path: '/home',                        component: { template: "<home></home>" } },
        { path: '/home/player',                 component: { template: "<home-player></home-player>" } },
        { path: '/home/creator',                component: { template: "<home-creator></home-creator>" } },
        { path: '/user/signin',                 component: { template: "<user-signin></user-signin>" } },
        { path: '/user/signout',                component: { template: "<user-signout></user-signout>" } },
        { path: '/user/create',                 component: { template: "<user-create></user-create>" } },
        { path: '/user/profile',                component: { template: "<user-profile></user-profile>" } },
        { path: '/groups/create',               component: { template: "<group-create></group-create>" } },
        { path: '/group/:groupId',              component: { template: "<group-edit></group-edit>" } },
        { path: '/group/:groupId/add-category', component: { template: "<group-add-category></group-add-category>" } },
        { path: '/group/:groupId/add-question', component: { template: "<group-add-question></group-add-question>" } },
        { path: '/group/:groupId/add-admin',    component: { template: "<group-add-admin></group-add-admin>" } },
        { path: '/group/:groupId/questions',    component: { template: "<group-questions></group-questions>" } },
        { path: '/question/:questionId',        component: { template: "<question></question>" } },
        { path: '/games/create',                component: { template: "<game-create></game-create>" } },
        { path: '/games/find',                  component: { template: "<game-find></game-find>" } },
        { path: '/game/:gameId/play',           component: { template: "<game-play></game-play>" } },
        { path: '/game/:gameId/review',         component: { template: "<game-review></game-review>" } },
        { path: '/game/:gameId/player-stats',   component: { template: "<game-player-stats></game-player-stats>" } },
        { path: '/stats/leaderboard',           component: { template: "<stats-leaderboard></stats-leaderboard>" } },
        { path: '/ping',                        component: { template: "<ping></ping>" } },
        { path: '*',                            component: { template: "<span>Unknown route!</span>" } }
    ];

    /**
     * Add custom filters to vue.
     */
    function addFilters() {
        
        // Use moment.js for date formatting.
        Vue.filter('dateFormat', function(value, fmt) {
            return moment(value).format(fmt);
          });
        
        // use numeral.js for number formatting.
        Vue.filter('numberFormat', function(value, fmt) {
            return numeral(value).format(fmt);
        });
        
        // A custom filter for making a text list. (Oxford comma!)
        Vue.filter('wordList', function (values) {
            var text = '';
            
            if (values.length == 1) {
                text += values[0];
            }
            else if (values.length == 2) {
                text += values[0] + " and " + values[1];
            }
            else {
                for (var i = 0; i < values.length; i++) {
                    if (i > 0) {
                        text += ", ";
                        if (i + 1 == values.length) {
                            text += "and ";
                        }
                    }
                    text += values[i];
                }
            }
            return text;
        });
    }
    
    /**
     * Setup a flux style store for global state management.
     */
    function createVuexStore() {
        return new Vuex.Store({
            
            state: {
                // A notification message.
                message: null,
                
                // An error message.
                errorMessage: null,
                
                // The logged in user.
                user: null,
                
                // Used to store the last route when the user was not signed in.
                // On sign the user will be redirected back to the attempted route.
                lastRoute: null
            },
            
            mutations: {
                
                /**
                 * Set the global notification message.
                 */
                setMessage: function(state, msg) {
                    state.message = msg;
                    state.errorMessage = null;
                },
                
                /**
                 * Set the global error message.
                 */
                setErrorMessage: function(state, msg) {
                    state.message = null;
                    state.errorMessage = msg;
                    console.log("Set error message: " + msg);
                },
                
                /**
                 * Clear out any error or notification messages.
                 */
                clearMessages: function(state) {
                    state.message = null;
                    state.errorMessage = null;
                },
                
                /**
                 * Unset the current user.
                 */
                clearUser: function(state) {
                    state.user = null;
                },
                
                /**
                 * Set the current user.
                 */
                setUser: function(state, user) {
                    state.user = user;
                },
                
                /**
                 * Set the last known route.
                 */
                setLastRoute: function(state, lastRoute) {
                    state.lastRoute = lastRoute;
                }
            },
            
            actions: {
                
                /**
                 * Initiate a user signout from the app.
                 */
                signout: function(context) {
                    var self = this;
                    var p = Promise.resolve($.ajax("/api/auth/signout", { method: 'POST', cache: false }));
                    p.then(
                        function() {
                            context.commit('clearUser');
                            window.location = "#/user/signin";
                        },
                        function(result) {
                            context.commit('setErrorMessage', result.responseText);
                            window.location = "#/user/signin";
                        }
                    );
                },
                
                /**
                 * Try and signin to the app with the given credentials.
                 */
                signin: function(context, credentials) {
                    var self = this;
                    var p = Promise.resolve($.ajax("/api/auth/signin",  {
                        method: 'POST',
                        contentType: 'application/json; charset=utf-8',
                        data: JSON.stringify(credentials)
                    }));
                    p.then(
                        function(result) {
                             if (result != null && result.userId != null) {
                                context.commit('setUser', result);
                                context.dispatch('onSignedIn');
                            }
                        },
                        function(result) {
                            context.commit('setErrorMessage', result.responseText);
                        }
                    );
                },
                
                /**
                 * Go to the correct page after signing in.
                 */
                onSignedIn: function(context) {
                    if (context.state.lastRoute != null) {
                        var lastRoute = context.state.lastRoute;
                        context.commit('setLastRoute', null);
                        window.location = lastRoute;
                    }
                    else {
                        window.location = '#/';
                    }
                },
                
                /**
                 * Check if the user is signed in or not.
                 * If they are not send them to the sign in page.
                 */
                assertSignedIn: function(context) {
                    if (context.state.user == null) {
                        var p = Promise.resolve($.ajax("/api/user", { method: 'GET', cache: false }));
                        p.then(
                           function(result) {
                               if (result != null && result.userId != null) {
                                   context.commit('setUser', result);
                               }
                               else {
                                   if (window.location.hash) {
                                       context.commit('setLastRoute', window.location.hash);
                                   }
                                   window.location = "#/user/signin";
                               }
                           },
                           function(result) {
                               context.commit('setErrorMessage', result.responseText);
                           }
                        );
                    }
                },
            }
        });
    }
    
    /**
     * Bootstrap the Vue application.
     */
    function bootstrapVue() {
        Vue.use(Vuex);
        addFilters();
        new Vue({
            router: new VueRouter({routes: routes}),
            el: '#app',
            store: createVuexStore(),
            template: '<router-view></router-view>'
        });
    }
    
    // Boot strap the vue application after the DOM has loaded.
    document.addEventListener('DOMContentLoaded', bootstrapVue, false);

})();