(function() {
    
    // This component is here just to check that the dev setup works
    // and that all the layers can communicate.
    
    Vue.component('ping', {
        template: '#ping-template',
        data: function() {
            return {
                status: "Pinging....."
            };
        },
        created: function() {
            this.onPing();
        },
        methods: {
            onPing: function() {
                // Calls the middle tier /api/ping.
                var self = this;
                $.ajax("/api/ping").then(function(result) {
                    self.status = result;
                });
            }
        }
    });
})();