(function() {
    Vue.component('requires-signin', {
        template: '#requires-signin-template',
        data: function() {
            return {
                hasUserInfo: false
            };
        },
        computed: {
            user: function() {
                return this.$store.state.user;
            }
        },
        created: function() {
            var self = this;
            self.$store.dispatch('assertSignedIn');
        }
    });
})();