(function() {
    Vue.component('group-add-admin', {
        template: '#group-add-admin-template',
        
        data: function() {
            return {
                groupId: null,
                group: null,
                email: null
            };
        },
        
        // Look up groups on startup.
        created: function() {
            var self = this;
            self.groupId = self.$route.params.groupId;
            var p = Promise.resolve($.ajax("/api/group/" + self.groupId));
            p.then(
                _.bind(self.onGroupRetrieved, self),
                _.bind(self.onFailure, self));
        },
        
        methods: {
            onSubmit: function() {
                var self = this;
                var p = Promise.resolve($.ajax("/api/group/" + self.groupId + "/administrators",  {
                    method: 'POST',
                    contentType: 'application/json; charset=utf-8',
                    data: JSON.stringify({
                        administratorEmail: self.email
                    })
                }));
                p.then(
                    _.bind(self.onAddAdminSuccess, self),
                    _.bind(self.onFailure, self));
            },
            
            onAddAdminSuccess: function(result) {
                var self = this;
                self.$store.commit('setMessage', "Administrator added.");
            },
            
            onGroupRetrieved: function(result) {
                var self = this;
                self.group = result;
            },
            
            onFailure: function(result) {
                var self = this;
                self.$store.commit('setErrorMessage', result.responseText);
            }
        }
    });
})();