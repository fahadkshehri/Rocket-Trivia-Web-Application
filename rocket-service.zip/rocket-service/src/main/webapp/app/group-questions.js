(function() {
    Vue.component('group-questions', {
        template: '#group-questions-template',
        
        data: function() {
            return {
                groupId: null,
                group: null,
                questions: []
            };
        },
        
        // Look up groups on startup.
        created: function() {
            var self = this;
            self.loadGroup();
            self.loadQuestions();
        },
        
        methods: {
            
            loadGroup: function() {
                var self = this;
                self.groupId = self.$route.params.groupId;
                var p = Promise.resolve($.ajax("/api/group/" + self.groupId));
                return p.then(
                    _.bind(self.onGroupRetrieved, self),
                    _.bind(self.onFailure, self));
            },
            
            loadQuestions: function() {
                var self = this;
                self.groupId = self.$route.params.groupId;
                var p = Promise.resolve($.ajax("/api/group/" + self.groupId + "/questions"));
                return p.then(
                    _.bind(self.onQuestionsRetrieved, self),
                    _.bind(self.onFailure, self));
            },
            
            onGroupRetrieved: function(group) {
                var self = this;
                self.group = group;
            },
            
            onQuestionsRetrieved: function(questions) {
                var self = this;
                self.questions = questions;
            },
            
            onFailure: function(result) {
                var self = this;
                self.$store.commit('setErrorMessage', result.responseText);
            }
        }
    });
})();