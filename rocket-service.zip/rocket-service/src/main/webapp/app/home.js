(function() {
    Vue.component('home', {
        template: '#home-template'
    });
})();