(function() {
    Vue.component('user-signout', {
        template: '<span><message></message></span>',
        data: function() {
            return {
            };
        },
        created: function() {
            var self = this;
            self.$store.dispatch('signout');
        }
    });
})();