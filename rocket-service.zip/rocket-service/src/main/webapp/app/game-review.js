(function() {
    Vue.component('game-review', {
        
        template: '#game-review-template',
        
        data: function() {
            return {
                gameId: null,
                answerReviews: null
            };
        },
        
        created: function() {
            var self = this;
            self.gameId = self.$route.params.gameId;
            if (self.user != null) {
                self.onUserKnown();
            }
        },

        computed: {
            user: function() {
                var self = this;
                return self.$store.state.user;
            }
        },
        
        watch: {
            user: function() {
                var self = this;
                if (self.user != null) {
                    self.onUserKnown();
                }
            }
        },
        
        methods: {
            
            onUserKnown: function() {
                var self = this;
                var url = "/api/user_game/" + self.user.userId + "/" + self.gameId + "/review";
                Promise.resolve($.ajax(url)).then(
                    _.bind(self.onUserGameQuestionAnswerReview, self),
                    _.bind(self.onFailure, self));
            },
            
            onUserGameQuestionAnswerReview: function(answerReviews) {
                var self = this;
                self.answerReviews = answerReviews;
            },
            
            onFailure: function() {
                this.$store.commit('setErrorMessage', result.responseText);
            }
        }
    });
})();