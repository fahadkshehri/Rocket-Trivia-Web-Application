// Common js functions and module go here.
(function() {

// Create a global object where common functions and modules go for the app.
// Global state management should occur in app.js though.
var rocket = {};
window.rocket = rocket;

})();

