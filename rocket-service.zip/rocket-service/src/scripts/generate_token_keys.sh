#!/bin/bash

res_dir=main/resources

openssl genrsa -out $res_dir/token_private_key.pem 2048
openssl pkcs8 -topk8 -inform PEM -outform DER -in $res_dir/token_private_key.pem -out $res_dir/token_private_key.der -nocrypt
openssl rsa -in $res_dir/token_private_key.pem -pubout -outform DER -out $res_dir/token_public_key.der
