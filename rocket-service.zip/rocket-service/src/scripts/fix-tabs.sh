#!/usr/bin/bash

# change tabs to spaces in the project source.

function convert_files() {
    while read f; do
        perl -p -i*.bak -e 's/\t/    /g;' $f
    done
}

find src -name "*.java" | convert_files
find src/main/webapp/app -name "*.js" | convert_files
find src/main/webapp/app -name "*.css" | convert_files
find src/main/webapp/app -name "*.html" | convert_files
find src/main/webapp/jslib -name "rocket.js" | convert_files

