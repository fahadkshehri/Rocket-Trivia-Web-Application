package rocket.security;

import org.junit.Assert;
import org.junit.Test;

public class AuthTokenTest {

    @Test
    public void testTokenGeneration() throws Exception {
        
        AuthTokenHandler atHandler = new AuthTokenHandler();
        String token = atHandler.generateToken(new AuthTokenIdentity(1));
        
        Assert.assertNotNull(token);
        
        AuthTokenIdentity identity = atHandler.parseAndValidate(token);
        Assert.assertEquals(identity.getUserId(), 1);
        Assert.assertNotNull(identity.getDateCreated());
    }
}
