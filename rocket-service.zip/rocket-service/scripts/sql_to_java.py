#!/bin/python
import sys 

def quote(line):
    return line.replace("\"", "\\\"")

for line in sys.stdin:
    line = line.rstrip('\n')
    print("        \"" + quote(line) + "\",") 

