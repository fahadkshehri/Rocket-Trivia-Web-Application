Rocket Trivia: Open Trivia Loader

This directory contain scripts to pull down trivia questions from the open trivia database:
    https://opentdb.com/

All of the content downloaded from open trivia is available under:
    https://creativecommons.org/licenses/by-sa/4.0/legalcode

There are 3 steps to getting Open Trivia questions into the Rocket Trivia database.

Step 1: Download Content

Run the python script open-trivia-downloader.py.
It will query the open trivia API and dump questions into the data directory.

Step 2: Reformat Questions to SQL

Run the python script convert_to_mysql_sql.py.
This script will read the json result files from the data directory and
generate "open_trivia_questions.sql".

Step 3: Run Generated SQL

Using the mysql command line or Mysql Admin run "open_trivia_questions.sql".

  Example:
  mysql -u rocket -p -h localhost rocket < open_trivia_questions.sql