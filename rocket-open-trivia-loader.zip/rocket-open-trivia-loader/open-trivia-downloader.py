#------------------------------------------------------------------------------
# Script: open-trivia-downloader.py
#
# Downloads trivia question data from opentb.com.
# Trivia questions will be written out as json files to the data directory.
#------------------------------------------------------------------------------
import os
import http.client
import json
import datetime

class OpenTriviaDBClient:
    def __init__(self, endpoint):
        self.endpoint = endpoint
        self.token = None

    def get_questions(self):
        path = "/api.php?amount=50"
        if self.token != None:
            path = path + "&token=" + self.token
        return self.make_get_request(path)

    def set_token(self, token):
        self.token = token

    def acquire_token(self):
        response = self.make_get_request("/api_token.php?command=request")
        self.set_token(response["token"])

    def make_get_request(self, path):
        conn = http.client.HTTPSConnection(self.endpoint)
        try:
            conn.request("GET", path)
            r = conn.getresponse()
            if r.status != 200:
                raise Exception("Could not retrieve token.")
            content = r.read()
            payload = json.loads(content)
            if payload["response_code"] == 0:
                return payload
            elif payload["response_code"] == 1:
                return None
            else:
                raise Exception("Error received: " + str(payload["response_code"]))
        finally:
            conn.close()

class Downloader:
    def __init__(self, endpoint, data_dir):
        self.data_dir = data_dir
        self.client = OpenTriviaDBClient(endpoint)

    def run(self, max_requests):
        self.client.acquire_token()
        if not os.path.exists(self.data_dir):
            os.makedirs(self.data_dir)

        t_stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
        req_count = 0
        while req_count < max_requests:
            questions = self.client.get_questions()
            if questions == None:
                break
            data_file = os.path.join(self.data_dir, "questions-" + t_stamp + "." + str(req_count + 1) + ".json")
            print("Writing content to: " + data_file)
            with open(data_file, "w") as fh:
                json.dump(questions, fh, sort_keys=True, indent=4)
            req_count = req_count + 1

def main():
    downloader = Downloader("opentdb.com", "data")
    downloader.run(70)

main()


