#------------------------------------------------------------------------------
# Script: convert_to_mysql_sql.py
#
# Filters questions downloaded from opentb.com and formats the data as
# insert statements suitable for the RocketTrivia schema.
#------------------------------------------------------------------------------
import os
import json
import html

class Converter:
    def __init__(self, data_dir):
        self.data_dir = data_dir
    
    def run(self, sql_file):

        # Group the questions by category
        questions_by_cat = {}
        for question in self.parse_questions():
            if not question["category"] in questions_by_cat:
                questions_by_cat[question["category"]] = []
            questions_by_cat[question["category"]].append(question)

        with open(sql_file, "w") as sql_out:

            sql_out.write("SET autocommit = 0;\n")
            sql_out.write("BEGIN;\n")

            # Generate Cleanup
            sql_out.write("-- Clean up previous data\n\n")
            sql_out.write("DELETE FROM Answer\n")
            sql_out.write("WHERE questionId IN (\n")
            sql_out.write("  SELECT q.questionId\n")
            sql_out.write("  FROM Question q\n")
            sql_out.write("  JOIN `Group` g ON (g.groupName = 'Open Trivia' AND g.groupId = q.groupId)\n")
            sql_out.write(");\n")

            sql_out.write("DELETE FROM Question_Category\n")
            sql_out.write("WHERE questionId IN (\n")
            sql_out.write("  SELECT q.questionId\n")
            sql_out.write("  FROM Question q\n")
            sql_out.write("  JOIN `Group` g ON (g.groupName = 'Open Trivia' AND g.groupId = q.groupId)\n")
            sql_out.write(");\n")

            sql_out.write("DELETE FROM Question\n")
            sql_out.write("WHERE groupId IN (\n")
            sql_out.write("  SELECT g.groupId\n")
            sql_out.write("  FROM `Group` g\n")
            sql_out.write("  WHERE g.groupName = 'Open Trivia'\n")
            sql_out.write(");\n")

            sql_out.write("DELETE FROM Category\n")
            sql_out.write("WHERE groupId IN (\n")
            sql_out.write("  SELECT g.groupId\n")
            sql_out.write("  FROM `Group` g\n")
            sql_out.write("  WHERE g.groupName = 'Open Trivia'\n")
            sql_out.write(");\n")

            sql_out.write("DELETE FROM Group_Administrator\n")
            sql_out.write("WHERE groupId IN (\n")
            sql_out.write("  SELECT g.groupId\n")
            sql_out.write("  FROM `Group` g\n")
            sql_out.write("  WHERE g.groupName = 'Open Trivia'\n")
            sql_out.write(");\n")

            sql_out.write("DELETE FROM `Group` WHERE groupName = 'Open Trivia';\n")
            sql_out.write("COMMIT;\n")

            # Create a group for the questions
            sql_out.write("BEGIN;\n")
            sql_out.write("-- Create the open trivia group\n")
            sql_out.write("INSERT INTO `Group` (GroupName, Description) VALUES (\n")
            sql_out.write("  'Open Trivia',\n")
            sql_out.write("  'Questions from Open Trivia Database (https://opentdb.com/). All content is available under: (https://creativecommons.org/licenses/by-sa/4.0/legalcode).');\n")
            sql_out.write("SET @groupId = LAST_INSERT_ID();\n")

            sql_out.write("INSERT INTO Group_Administrator\n")
            sql_out.write("SELECT u.userId, @groupId\n")
            sql_out.write("FROM User u\n")
            sql_out.write("WHERE u.Email in ('castillo.bryan@gmail.com', 'maridha@uw.edu', 'trecewicklander@hotmail.com', 'fahaduwb@uw.edu');\n")

            seen_questions = set()

            # Create the questions for each category.
            for category in questions_by_cat.keys():
                sql_out.write("\n-- Generating content for category: {}\n".format(category))
                sql_out.write("INSERT INTO Category (CategoryName, GroupId) VALUES ({}, @groupId);\n".format(self.to_sql_string(category)))
                sql_out.write("SET @categoryId = LAST_INSERT_ID();\n\n")

                for question in questions_by_cat[category]:
                    content = self.to_sql_string(question["question"])

                    if content in seen_questions:
                        continue
                    
                    seen_questions.add(content)

                    sql_out.write("INSERT INTO Question (Content, GroupId) VALUES ({}, @groupId);\n".format(content))
                    sql_out.write("SET @questionId = LAST_INSERT_ID();\n")
                    sql_out.write("INSERT INTO Question_Category (CategoryId, QuestionId) VALUES(@categoryId, @questionId);\n")

                    content = self.to_sql_string(question["correct_answer"])
                    sql_out.write("INSERT INTO Answer VALUES(1, @questionId, {}, 1);\n".format(content))

                    answerNum = 1
                    for answer in question["incorrect_answers"]:
                        answerNum = answerNum + 1
                        content = self.to_sql_string(answer)
                        sql_out.write("INSERT INTO Answer VALUES({}, @questionId, {}, 0);\n".format(answerNum, content))

            sql_out.write("COMMIT;\n")

    def to_sql_string(self, s):
        ns = "'"
        for c in s:
            if c == '\n':
                ns = ns + "\\n"
            elif c == '\r':
                ns = ns + "\\r"
            elif c == '\t':
                ns = ns + "\\t"
            elif c == '\\':
                ns = ns + "\\\\"
            elif c == '%':
                ns = ns + "\\%"
            elif c == '_':
                ns = ns + "\\_"
            elif c == '\'':
                ns = ns + "''"
            elif c == '"':
                ns = ns + "\\\""
            else:
                ns = ns + c
        ns = ns + "'"
        return ns

    def has_basic_strings(self, result):
        def is_clean(s):
            for c in s:
                n = ord(c)
                if n >= 128 or n < 32:
                    return False
            return True

        for a in result["incorrect_answers"]:
            if not is_clean(a):
                return False

        return is_clean(result["question"]) and \
               is_clean(result["correct_answer"]) and \
               is_clean(result["category"])

    def parse_questions(self):
        files = os.listdir(self.data_dir)
        for f in files:
            if f.endswith(".json"):
                with open(os.path.join(self.data_dir, f), "r") as fh:
                    data = json.load(fh)
                    for result in data["results"]:
                        if result["type"] != "multiple":
                            continue
                        if len(result["incorrect_answers"]) < 3:
                            continue

                        result["question"] = html.unescape(result["question"])
                        result["correct_answer"] = html.unescape(result["correct_answer"])
                        result["incorrect_answers"] = [html.unescape(a) for a in result["incorrect_answers"]]
                        result["category"] = html.unescape(result["category"])

                        if not self.has_basic_strings(result):
                            continue

                        yield result


converter = Converter("data")
converter.run("open_trivia_questions.sql")