-- ============================================================================
-- Creates some test questions and categories.
-- ============================================================================

-- Add some categories

INSERT INTO Category (CategoryName, GroupId)
VALUES (
  'Science',
  (SELECT GroupId FROM `Group` WHERE GroupName = 'Team Rocket')
);

INSERT INTO Category (CategoryName, GroupId)
VALUES (
  'P.E.',
  (SELECT GroupId FROM `Group` WHERE GroupName = 'Team Rocket')
);

INSERT INTO Category (CategoryName, GroupId)
VALUES (
  'Science',
  (SELECT GroupId FROM `Group` WHERE GroupName = 'UW Bothell')
);

INSERT INTO Category (CategoryName, GroupId)
VALUES (
  'Computer Science',
  (SELECT GroupId FROM `Group` WHERE GroupName = 'UW Bothell')
);

-- Add some questions.

SET @groupId = (SELECT GroupId FROM `Group` WHERE GroupName = 'UW Bothell');

INSERT INTO Question (Content, GroupId)
VALUES (
  'What is the chemical makeup of water?',
  (SELECT GroupId FROM `Group` WHERE GroupName = 'UW Bothell')
);

SET @qid = LAST_INSERT_ID();

INSERT INTO Answer
VALUES (1, @qid, 'H2O', True);

INSERT INTO Answer
VALUES (2, @qid, 'CO2', False);

INSERT INTO Answer
VALUES (3, @qid, 'H3O', False);

INSERT INTO Answer
VALUES (4, @qid, 'CH4', False);

INSERT INTO Question_Category
VALUES (
  (SELECT CategoryId FROM Category WHERE GroupId = @groupId AND CategoryName = 'Science'),
  @qid
);
