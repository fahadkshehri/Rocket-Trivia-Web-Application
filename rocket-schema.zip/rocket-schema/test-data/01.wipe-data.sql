-- ============================================================================
-- Clears out all data and resets counters.
-- ============================================================================

-- Clean out data.
DELETE FROM User_Game_QA_Pick;
DELETE FROM User_Games;
DELETE FROM Game_Question_Answer;
DELETE FROM Game_Question;
DELETE FROM Game;
DELETE FROM Group_Administrator;
DELETE FROM Question_Category;
DELETE FROM Category;
DELETE FROM Answer;
DELETE FROM Question;
DELETE FROM `Group`;
DELETE FROM User;

-- Resets auto-increments
ALTER TABLE Question AUTO_INCREMENT = 1;
ALTER TABLE Category AUTO_INCREMENT = 1;
ALTER TABLE `Group` AUTO_INCREMENT = 1;
ALTER TABLE User AUTO_INCREMENT = 1;
ALTER TABLE Game AUTO_INCREMENT = 1;
