-- ============================================================================
-- Creates Initial Users and Trivia Groups.
-- ============================================================================

-- Add the oficial team rocket users.
-- Keep static IDs from production.

INSERT INTO `User` (`UserId`,`Email`,`Alias`,`PasswordHash`)
VALUES (1,'castillo.bryan@gmail.com','bryan','NLPHDHR6eOgspfxeIzozbdisld5hS9O_A2OYt9U2zqw');

INSERT INTO `User` (`UserId`,`Email`,`Alias`,`PasswordHash`)
VALUES (4,'maridha@uw.edu','TechFatih','HF69uXo-j8ofUa7wHbJ4dWLv21GzsC1RU7JJjm2udPY');

INSERT INTO `User` (`UserId`,`Email`,`Alias`,`PasswordHash`)
VALUES (5,'trecewicklander@hotmail.com','Trece','su0YrgVwz8bkXkODb3vl-PxpCaesOBknZYcYSSxLMoo');

INSERT INTO `User` (`UserId`,`Email`,`Alias`,`PasswordHash`)
VALUES (6,'fahaduwb@uw.edu','Fahad','Pqh6Vto4RLQg7CklrpIrxzHsFqT8RNy-r9rUmw5h05w');

-- This is the test user for grading.
-- The password is cuniculus
INSERT INTO `User` (`Email`,`Alias`,`PasswordHash`)
VALUES ('css451-tester@uw.edu','CSS451Tester','4RiFujva8vn3QO7wt6bciVd76sbVen7uTOnnoplRCAw');

-- Add some test users.

-- password: pw1
INSERT INTO User (Email, Alias, PasswordHash)
VALUES ('bob@gmail.com', 'bob', 'xZLfSoaTO5Kt3JhCQC3fGYxjjqm-WJFu5uNzTh4xUvg');

-- password: pw2
INSERT INTO User (Email, Alias, PasswordHash)
VALUES ('joe@gmail.com', 'joe', 'k5FaCkv49jTLGFZJTdQwRHKtRrmCf1QfdrZ2HEnMVbA');

-- password: pw3
INSERT INTO User (Email, Alias, PasswordHash)
VALUES ('zoe@gmail.com', 'zoe', 'Byqp6fudUWLkZdMyFTBGPK7NWbFWZ2_jBxmXzcEBeBY');

-- Create a couple groups.

INSERT INTO `Group` (GroupName, Description) VALUES ('Team Rocket', 'The best group');
INSERT INTO `Group` (GroupName, Description) VALUES ('UW Bothell', 'They will have jobs.');

INSERT INTO Group_Administrator VALUES (
  (SELECT UserId FROM User WHERE Email = 'bob@gmail.com'),
  (SELECT GroupId FROM `Group` WHERE GroupName = 'UW Bothell')
);

INSERT INTO Group_Administrator VALUES (
  (SELECT UserId FROM User WHERE Email = 'joe@gmail.com'),
  (SELECT GroupId FROM `Group` WHERE GroupName = 'UW Bothell')
);

INSERT INTO Group_Administrator VALUES (
  (SELECT UserId FROM User WHERE Email = 'zoe@gmail.com'),
  (SELECT GroupId FROM `Group` WHERE GroupName = 'UW Bothell')
);

-- Add Team Rocket "real" people to groups.
INSERT IGNORE INTO Group_Administrator
SELECT u.UserId, g.GroupId
FROM User u, `Group` g
WHERE
  u.Email IN (
    'castillo.bryan@gmail.com',
    'maridha@uw.edu',
    'trecewicklander@hotmail.com',
    'fahaduwb@uw.edu',
    'css451-tester@uw.edu');
