This directory contains scripts for setting up the rocket database.
