-- Creates the user table.

DROP TABLE IF EXISTS User;

CREATE TABLE User (
  UserId INTEGER NOT NULL AUTO_INCREMENT,
  Email VARCHAR(200) NOT NULL,
  Alias VARCHAR(100) NOT NULL,
  PasswordHash VARCHAR(100) NOT NULL,
  PRIMARY KEY(UserId),
  UNIQUE(Email)
);

-- TRIGGERS FOR INSERTING AN EMAIL, ALIAS, AND PASSWORD HASH
delimiter $
create trigger USER_CHECK_INS before insert on User 
for each row 
begin  
	if (CHAR_LENGTH(new.Email) < 1 OR new.Email REGEXP '^[[:space:]]' OR new.Email REGEXP '[[:space:]]$')
	then
		signal sqlstate '45000' set message_text = 'Email Error';
        
	elseif (CHAR_LENGTH(new.Alias) < 1 OR new.Alias REGEXP '^[[:space:]]' OR new.Alias REGEXP '[[:space:]]$')
	then
		signal sqlstate '45000' set message_text = 'Alias Error';
        
	elseif (CHAR_LENGTH(new.PasswordHash) < 1 OR new.PasswordHash REGEXP '^[[:space:]]' OR new.PasswordHash REGEXP '[[:space:]]$')
	then
		signal sqlstate '45000' set message_text = 'Password Error';
	
	end if;
end$

-- TRIGGERS FOR UPDATING AN EMAIL, ALIAS, AND PASSWORD HASH
create trigger USER_CHECK_UP before update on User 
for each row 
begin  
	if (CHAR_LENGTH(new.Email) < 1 OR new.Email REGEXP '^[[:space:]]' OR new.Email REGEXP '[[:space:]]$')
	then
		signal sqlstate '45000' set message_text = 'Email Error';
        
	elseif (CHAR_LENGTH(new.Alias) < 1 OR new.Alias REGEXP '^[[:space:]]' OR new.Alias REGEXP '[[:space:]]$')
	then
		signal sqlstate '45000' set message_text = 'Alias Error';
        
	elseif (CHAR_LENGTH(new.PasswordHash) < 1 OR new.PasswordHash REGEXP '^[[:space:]]' OR new.PasswordHash REGEXP '[[:space:]]$')
	then
		signal sqlstate '45000' set message_text = 'Password Error';
	
	end if;
end$

delimiter ;