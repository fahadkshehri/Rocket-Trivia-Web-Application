-- Creates the user table.

DROP TABLE IF EXISTS Group_Administrator;
DROP TABLE IF EXISTS `Group`;

CREATE TABLE `Group` (
  GroupId INTEGER NOT NULL AUTO_INCREMENT,
  GroupName VARCHAR(100) NOT NULL,
  Description VARCHAR(200) NOT NULL,
  PRIMARY KEY(GroupId),
  UNIQUE(GroupName)
);

CREATE TABLE Group_Administrator (
  UserId INTEGER NOT NULL,
  GroupId INTEGER NOT NULL,
  PRIMARY KEY(UserId, GroupId),
  FOREIGN KEY (UserId) REFERENCES User (UserId),
  FOREIGN KEY (GroupId) REFERENCES `Group` (GroupId)
);

-- TRIGGERS FOR INSERTING A GroupName and Group Description
delimiter $
create trigger GROUP_TRIGGER_INS before insert on `Group`
for each row 
begin  
	if (CHAR_LENGTH(new.GroupName) < 1 OR new.GroupName REGEXP '^[[:space:]]' OR new.GroupName REGEXP '[[:space:]]$')
	then
		signal sqlstate '45000' set message_text = 'GroupName Error';
    
    elseif (CHAR_LENGTH(new.Description) < 1 or new.Description REGEXP '^[[:space:]]' OR new.Description REGEXP '[[:space:]]$')
    then
		signal sqlstate '45000' set message_text = 'Description Error';
	end if;
end$

-- TRIGGERS FOR UPDATING A GroupName and Group Description
delimiter $
create trigger GROUP_TRIGGER_UP before update on `Group`
for each row 
begin  
	if (CHAR_LENGTH(new.GroupName) < 1 OR new.GroupName REGEXP '^[[:space:]]' OR new.GroupName REGEXP '[[:space:]]$')
	then
		signal sqlstate '45000' set message_text = 'Password Error';
    
    elseif (CHAR_LENGTH(new.Description) < 1 or new.Description REGEXP '^[[:space:]]' OR new.Description REGEXP '[[:space:]]$')
    then
		signal sqlstate '45000' set message_text = 'Password Error';
	end if;
end$

delimiter ;
