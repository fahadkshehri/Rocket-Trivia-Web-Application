-- Creates the game tables

DROP TABLE IF EXISTS Game_Question_Answer;
DROP TABLE IF EXISTS Game_Question;
DROP TABLE IF EXISTS Game;

CREATE TABLE Game (
  GameId INTEGER NOT NULL AUTO_INCREMENT,
  Created TIMESTAMP NOT NULL,
  EndTime TIMESTAMP NOT NULL,
  MaxQuestionTime INT NOT NULL,
  UserId INT NOT NULL,
  CONSTRAINT GamePK
    PRIMARY KEY(GameId),
  CONSTRAINT GameFK
    FOREIGN KEY(UserId) REFERENCES User (UserId),
  CONSTRAINT GameValidEndTime
    CHECK (EndTime > Created),
  CONSTRAINT GameValidMaxTime
    CHECK (MaxQuestionTime > 0)
);

CREATE TABLE Game_Question (
  GameQNum INT NOT NULL,
  GameId INT NOT NULL,
  QuestionId INT NOT NULL,
  CONSTRAINT GameQuestionPK
    PRIMARY KEY(GameQNum, GameId),
  CONSTRAINT GameQuestionFKGID
    FOREIGN KEY(GameId) REFERENCES Game (GameId),
  CONSTRAINT GameQuestionFKQID
    FOREIGN KEY(QuestionId) REFERENCES Question (QuestionId)
);

CREATE TABLE Game_Question_Answer (
  GameQANum INT NOT NULL,
  GameQNum INT NOT NULL,
  GameId INT NOT NULL,
  QuestionId INT NOT NULL,
  AnswerNumber INT NOT NULL,
  CONSTRAINT GameQuestionAnswerPK
    PRIMARY KEY(GameQANum, GameQNum, GameId),
  CONSTRAINT GameQuestionAnswerFKGQ
    FOREIGN KEY(GameQNum, GameId) REFERENCES Game_Question (GameQNum, GameId),
  CONSTRAINT GameQuestionAnswerFKAnswer
    FOREIGN KEY(AnswerNumber, QuestionId) REFERENCES Answer (AnswerNumber, QuestionId)
);
