-- Create the user game tables

DROP TABLE IF EXISTS User_Game_QA_Pick;
DROP TABLE IF EXISTS User_Games;

CREATE TABLE User_Games (
  UserId INT NOT NULL,
  GameId INT NOT NULL,
  TimeStarted TIMESTAMP NOT NULL,
  CONSTRAINT UserGamePK
    PRIMARY KEY(UserId, GameId),
  CONSTRAINT UserGameFKUser
    FOREIGN KEY(UserId) REFERENCES User (UserId),
  CONSTRAINT UserGameFKGame
    FOREIGN KEY(GameId) REFERENCES Game (GameId)
);

CREATE TABLE User_Game_QA_Pick (
  UserId INT NOT NULL,
  GameId INT NOT NULL,
  GameQNum INT NOT NULL,
  GameQANum INT NOT NULL,
  TimeChosen TIMESTAMP NOT NULL,
  TimeElapsed INT NOT NULL,
  CONSTRAINT UserGameQAPickPK
    PRIMARY KEY(UserId, GameId, GameQNum, GameQANum),
  CONSTRAINT UserGameQAPickFKUID
    FOREIGN KEY(UserId) REFERENCES User (UserId),
  CONSTRAINT UserGameQAPickFKGQA
    FOREIGN KEY(GameQANum, GameQNum, GameId) REFERENCES Game_Question_Answer (GameQANum, GameQNum, GameId)
);

DROP TRIGGER IF EXISTS USER_GAME_TRIGGER_INS;
DROP TRIGGER IF EXISTS USER_GAME_TRIGGER_UP;
DROP TRIGGER IF EXISTS USER_GAME_QA_PICK_TRIGGER_INS;
DROP TRIGGER IF EXISTS USER_GAME_QA_PICK_TRIGGER_UP;

-- These triggers are disabled for now.
-- The user interface doesn't support timing.
/*
-- Triggers for User Game
delimiter $
create trigger USER_GAME_TRIGGER_INS before insert on User_Games
for each row 
begin  
	if NOT (new.TimeStarted BETWEEN
      (SELECT Created FROM Game G WHERE G.GameId = new.GameID) AND
	  (SELECT EndTime FROM Game G WHERE G.GameId = new.GameID))
	then
		signal sqlstate '45000' set message_text = 'User Game Error';
	end if;
end$

delimiter $
create trigger USER_GAME_TRIGGER_UP before update on User_Games
for each row 
begin  
	if NOT (new.TimeStarted BETWEEN
      (SELECT Created FROM Game G WHERE G.GameId = new.GameID) AND
	  (SELECT EndTime FROM Game G WHERE G.GameId = new.GameID))
	then
		signal sqlstate '45000' set message_text = 'User Game Error';
	end if;
end$

-- Triggers for User Game QA Pick
delimiter $
create trigger USER_GAME_QA_PICK_TRIGGER_INS before insert on User_Game_QA_Pick
for each row 
begin  
	if NOT (new.TimeChosen BETWEEN
      (SELECT Created FROM Game G WHERE G.GameId = new.GameID) AND
	  (SELECT EndTime FROM Game G WHERE G.GameId = new.GameID))
	then
		signal sqlstate '45000' set message_text = 'User Game QA Pick Error: Game has ended.';
        
	elseif NOT (new.TimeElapsed BETWEEN 0 AND (SELECT MaxQuestionTime FROM Game G WHERE G.GameId = new.GameId))
    then
		signal sqlstate '45000' set message_text = 'User Game QA Pick Error: too long to answer question.';
	end if;
end$

delimiter $
create trigger USER_GAME_QA_PICK_TRIGGER_UP before update on User_Game_QA_Pick
for each row 
begin  
	if NOT (new.TimeChosen BETWEEN
      (SELECT Created FROM Game G WHERE G.GameId = new.GameID) AND
	  (SELECT EndTime FROM Game G WHERE G.GameId = new.GameID))
	then
		signal sqlstate '45000' set message_text = 'User Game QA Pick Error: Game has ended.';
        
	elseif NOT (new.TimeElapsed BETWEEN 0 AND (SELECT MaxQuestionTime FROM Game G WHERE G.GameId = new.GameId))
    then
		signal sqlstate '45000' set message_text = 'User Game QA Pick Error: too long to answer question.';
	end if;
end$

delimiter ;
*/