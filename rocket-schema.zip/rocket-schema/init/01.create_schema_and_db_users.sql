DROP SCHEMA IF EXISTS rocket;

CREATE SCHEMA IF NOT EXISTS rocket;

CREATE USER 'rocket'@'%' IDENTIFIED BY 'kN78z-ng~148A';
CREATE USER 'rocket'@'localhost' IDENTIFIED BY 'kN78z-ng~148A';
GRANT ALL PRIVILEGES ON rocket.* TO 'rocket'@'%';
GRANT ALL PRIVILEGES ON rocket.* TO 'rocket'@'localhost';
GRANT ALTER ON rocket.* TO 'rocket'@'localhost';
GRANT ALTER ON rocket.* TO 'rocket'@'%';


CREATE USER 'css451-tester'@'%' IDENTIFIED BY 'cuniculus';
CREATE USER 'css451-tester'@'localhost' IDENTIFIED BY 'cuniculus';
GRANT ALL PRIVILEGES ON rocket.* TO 'css451-tester'@'%';
GRANT ALL PRIVILEGES ON rocket.* TO 'css451-tester'@'localhost';
GRANT ALTER ON rocket.* TO 'css451-tester'@'localhost';
GRANT ALTER ON rocket.* TO 'css451-tester'@'%';