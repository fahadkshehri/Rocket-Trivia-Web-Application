
DROP TABLE IF EXISTS Question_Category;
DROP TABLE IF EXISTS Answer;
DROP TABLE IF EXISTS Question;
DROP TABLE IF EXISTS Category;

CREATE TABLE Category (
  CategoryId INTEGER NOT NULL AUTO_INCREMENT,
  CategoryName VARCHAR(100) NOT NULL,
  GroupId INTEGER NOT NULL,
  PRIMARY KEY(CategoryId),
  UNIQUE(CategoryName, GroupId),
  FOREIGN KEY (GroupId) REFERENCES `Group` (GroupId)
);

CREATE TABLE Question (
  QuestionId INTEGER NOT NULL AUTO_INCREMENT,
  Content VARCHAR(500) NOT NULL,
  GroupId INTEGER NOT NULL,
  PRIMARY KEY(QuestionId),
  FOREIGN KEY (GroupId) REFERENCES `Group` (GroupId)
);

CREATE TABLE Answer (
  AnswerNumber INTEGER NOT NULL,
  QuestionId INTEGER,
  Content VARCHAR(500) NOT NULL,
  Correct BOOLEAN NOT NULL,
  PRIMARY KEY(AnswerNumber, QuestionId),
  FOREIGN KEY(QuestionId) REFERENCES Question (QuestionId)
);

CREATE TABLE Question_Category (
  CategoryId INTEGER NOT NULL,
  QuestionId INTEGER NOT NULL,
  PRIMARY KEY(CategoryId, QuestionId),
  FOREIGN KEY(CategoryId) REFERENCES Category (CategoryId),
  FOREIGN KEY(QuestionId) REFERENCES Question (QuestionId),
  CONSTRAINT CHECK_SAME_GROUP
  CHECK (
    (SELECT c.groupId FROM Category c WHERE c.categoryId = categoryId) =
    (SELECT q.groupId FROM Question q WHERE q.categoryId = categoryId)
  )
);

DROP TRIGGER IF EXISTS CATEGORY_TRIGGER_INS;
DROP TRIGGER IF EXISTS CATEGORY_TRIGGER_UP;
DROP TRIGGER IF EXISTS QUESTION_TRIGGER_INS;
DROP TRIGGER IF EXISTS QUESTION_TRIGGER_UP;
DROP TRIGGER IF EXISTS ANSWER_TRIGGER_INS;
DROP TRIGGER IF EXISTS ANSWER_TRIGGER_UP;

-- Triggers for Category
delimiter $
create trigger CATEGORY_TRIGGER_INS before insert on Category
for each row 
begin  
	if (CHAR_LENGTH(new.CategoryName) < 1 OR new.CategoryName REGEXP '^[[:space:]]' OR new.CategoryName REGEXP '[[:space:]]$')
	then
		signal sqlstate '45000' set message_text = 'Category Error';
	end if;
end$

delimiter $
create trigger CATEGORY_TRIGGER_UP before update on Category
for each row 
begin  
	if (CHAR_LENGTH(new.CategoryName) < 1 OR new.CategoryName REGEXP '^[[:space:]]' OR new.CategoryName REGEXP '[[:space:]]$')
	then
		signal sqlstate '45000' set message_text = 'Category Error';
	end if;
end$

-- Triggers for Question 
delimiter $
create trigger QUESTION_TRIGGER_INS before insert on Question
for each row 
begin  
	if (CHAR_LENGTH(new.Content) < 1 OR new.Content REGEXP '^[[:space:]]' OR new.Content REGEXP '[[:space:]]$')
	then
		signal sqlstate '45000' set message_text = 'Question Error';
        
	elseif (EXISTS(SELECT 1 FROM Question WHERE GroupID = new.GroupID and Content = new.Content))
    then
		signal sqlstate '45000' set message_text = 'Question Error';
	end if;
end$

delimiter $
create trigger QUESTION_TRIGGER_UP before update on Question
for each row 
begin  
	if (CHAR_LENGTH(new.Content) < 1 OR new.Content REGEXP '^[[:space:]]' OR new.Content REGEXP '[[:space:]]$')
	then
		signal sqlstate '45000' set message_text = 'Question Error';
        
	elseif (EXISTS(SELECT 1 FROM Question WHERE GroupID = new.GroupID and Content = new.Content))
    then
		signal sqlstate '45000' set message_text = 'Question Error';
	end if;
end$

-- Triggers for Answer
delimiter $
create trigger ANSWER_TRIGGER_INS before insert on Answer
for each row 
begin  
	if (CHAR_LENGTH(new.Content) < 1 OR new.Content REGEXP '^[[:space:]]' OR new.Content REGEXP '[[:space:]]$') OR (new.AnswerNumber < 0)
	then
		signal sqlstate '45000' set message_text = 'Answer Error';
        
	elseif (EXISTS(SELECT 1 FROM Answer WHERE QuestionId = new.QuestionId and Content = new.Content))
    then
		signal sqlstate '45000' set message_text = 'Answer Error';
	end if;
end$

delimiter $
create trigger ANSWER_TRIGGER_UP before update on Answer
for each row 
begin  
	if (CHAR_LENGTH(new.Content) < 1 OR new.Content REGEXP '^[[:space:]]' OR new.Content REGEXP '[[:space:]]$') OR (new.AnswerNumber < 0)
	then
		signal sqlstate '45000' set message_text = 'Answer Error';
        
	elseif (EXISTS(SELECT 1 FROM Answer WHERE QuestionId = new.QuestionId and Content = new.Content))
    then
		signal sqlstate '45000' set message_text = 'Answer Error';
	end if;
end$

delimiter ;