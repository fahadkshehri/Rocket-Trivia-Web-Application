
-- Drop all tables.

DROP TABLE IF EXISTS User_Game_QA_Pick;
DROP TABLE IF EXISTS User_Games;

DROP TABLE IF EXISTS Game_Question_Answer;
DROP TABLE IF EXISTS Game_Question;
DROP TABLE IF EXISTS Game;

DROP TABLE IF EXISTS Answer;
DROP TABLE IF EXISTS Question_Category;
DROP TABLE IF EXISTS Question;

DROP TABLE IF EXISTS Group_Administrator;
DROP TABLE IF EXISTS Category;
DROP TABLE IF EXISTS `Group`;

DROP TABLE IF EXISTS User;

