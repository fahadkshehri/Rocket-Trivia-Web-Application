# Use this script to generate a password hash from a password.
# This script should create hashes with the same values the java
# code would.
import sys
import hashlib
import base64

if len(sys.argv) != 2:
    print("Usage: {0} <password>".format(sys.argv[0]), file=sys.stderr)
    sys.exit(1)

password = sys.argv[1]
m = hashlib.sha256()
m.update(password.encode('utf-8'))
bd = m.digest()
pw_hash = base64.urlsafe_b64encode(bd).decode('ascii').replace('=', '')

print(pw_hash)
